HOSTILE-OS SMUGGLE PATCH 002

Purpose:
Repair the QEMU runtime transplant from Smuggle 001.

Contents:
- QEMU loadable modules
- BIOS/VGA firmware
- NONCANONICAL Minimal_FS control

Expected lab integration:

    QEMU_MODULE_DIR=<patch>/runtime/qemu/modules

The firmware files should be merged into:

    runtime/qemu/share/qemu/

The Minimal_FS control remains quarantined and may not support
canonical donor claims.

SCIENTIFIC PASS COUNT DOES NOT INCREASE MERELY BY RECEIVING THIS PATCH.
