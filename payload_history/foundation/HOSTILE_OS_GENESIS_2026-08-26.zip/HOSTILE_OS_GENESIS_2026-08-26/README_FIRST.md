# HOSTILE-OS GENESIS PACKAGE

**Built:** 2026-08-26  
**Working name:** HOSTILE-OS (provisional working name)  
**Motto:** `FREE-DOS + LINUX -> FUCK WINDOWS, AGAIN.`

This package founds the hostile-engineered OS research line under the existing ProtoAGI/HSP process. It is intentionally a **Foundation F0 package**, not a fake Pass 1.

## Recovery order

1. `00_REINCARNATION_BOOTLOADER.md`
2. `01_CONTINUOUS_FORENSIC_HISTORY.md` and `docs/HOSTILE_OS_CONTINUOUS_FORENSIC_HISTORY_2026-08-26.docx`
3. `02_CONSTITUTION_AND_LAWS.md`
4. `03_CROSS_PROJECT_QUARRY_LEDGER.md`
5. `04_DONOR_LOCK_AND_CONTAMINATION_LEDGER.md`
6. `05_CAMPAIGN_000_PREREGISTRATION.md`
7. `06_ATTENTION_RESERVOIR.md`
8. `08_NEVER_SILENTLY_REINTRODUCE.md`
9. `CONTINUITY_STATE.json`
10. `RESUME_PROMPT.txt`

## Package truth ceiling

The Linux 0.01 and FreeDOS source identities are pinned, but the donor bytes were not successfully downloaded inside the current ChatGPT container. Therefore this package does **not** claim source analysis, build success, boot success, or Campaign Pass 1 evidence.

The next operation is deliberately executable and durable: `tools/fetch_and_lock_donors.sh`, followed by inspection of its log/receipt.

## Why the continuous history is separate

The reincarnation bootloader is optimized for rapid recovery. The continuous forensic history preserves the reasons, corrections, scars, rejected branches, contamination and Commander's Intent that compact handoffs tend to erase. Both are required continuity artifacts.
