# Continuous Forensic History and Commander's Intent

## Purpose of this document

This is the **continuous forensic history companion** to the reincarnation bootloader. It exists because compact handoffs repeatedly proved insufficient for long-lived R&D. A replacement thread must not merely know the latest architecture. It must understand **how the project arrived there, which choices were corrected, what failures produced each law, which old mechanisms are forbidden to silently return, and where prior-project ancestry contaminates claims of rediscovery**.

The document therefore preserves chronology, engineering decisions, Commander's Intent, addenda, authority changes, donor boundaries, scars, rejected/deferred paths, and exact next lawful operation.

It is deliberately more granular than a summary. The compact bootloader tells a replacement thread where it is. This document tells it **why**.

---

## I. Deep ancestry: direct machine sovereignty before the current vocabulary (2024-2025)

The operating-system line did not begin on 26 August 2026.

A recovered October 2024 project thread already contained the core experimental instinct: place AI-assisted engineering against a sacrificial but capable physical computer, begin near firmware/bootstrapping, and iteratively build an operating system upward while using actual hardware consequence as the arbiter. The preference was not to spend the experiment permanently trapped behind inherited driver/application abstractions. By February 2025 this intuition had expanded toward an AI/system relationship in which the intelligence was intertwined deeply enough with the operating substrate to participate in resource allocation, scheduling, power/security decisions, and hardware utilization.

This matters for two reasons.

First, the 2026 project is a **mature resurrection of an unresolved research line**, not a claim that the idea appeared from nowhere during a joke about FreeDOS.

Second, it creates contamination. Direct-hardware-first OS design, adaptive substrate probing, and later scheduler/ECS intuitions are part of our ancestry. If they reappear in the new experiment, the correct claim is that they survived re-derivation under new evidence, not that we independently invented them in ignorance.

### Commander's Intent inherited from this era

Take the machine seriously as a physical substrate. Do not confuse the operating-system conventions we inherited with the irreducible responsibilities reality imposes.

---

## II. Holonix / Holonic OS / Holonic Linux (December 2025)

By late December 2025, the earlier hardware-sovereignty instinct had acquired explicit holonic and ECS-like OS formulations. Connected Drive retains `Holonic OS Design Specification`, `Holonic Linux Design Specification`, `Holonic OS Research & Design`, and related tablet/Linux artifacts.

Important ideas present in that lineage included:

- a minimal primordial kernel responsible for close-to-physical truth such as time, memory and interrupts;
- ECS/data-oriented representations for system state;
- holons as functional wholes that can also be parts of larger wholes;
- state reconciliation rather than a ceremonial startup sequence;
- content-addressed/append-preserving/provenance-bearing storage ideas;
- energy/joules as an explicit resource;
- graceful degradation and triage;
- capability-based security and WASM-style constrained application ideas;
- fault injection and chaos pressure;
- locality, NUMA and batching pressure;
- use of existing Android/Linux driver/HAL machinery as substrate capability instead of reimplementing everything.

That last idea is especially important because it independently resembles the later FtD law: **orchestrate native computation already present in the substrate rather than replicating it above the substrate**.

But this era also contains exactly the failure mode the current process must prevent: architecture and vocabulary raced far ahead of embodiment. Biomimetic analogies, theoretical-limit language, Landauer rhetoric, semantic-filesystem ambitions and `God-tier` claims sometimes hardened into specifications faster than external evidence justified them.

### Scar extracted

A compelling organizing metaphor can become a self-justifying ontology if descendant documents cite one another. Therefore **ancestry is not corroboration** and old Holonix structure is contamination, not evidence that the new OS should be holonic.

---

## III. CogOS / Codex Omega / NEAL / IW-CO / CIL explosion (late 2025 - early 2026)

The same period produced a larger family of architecture and engineering doctrine: CogOS, Codex Omega, NEAL, IW-CO, CIL/Quipu and related work.

### What survived

CogOS usefully treated the whole computer as a coupled resource envelope. CPU, GPU, memory bandwidth, latency and thermal headroom are not independent optimizers. A local win can make the machine worse. This became a precursor to the new Pareto law.

CIL eventually yielded a durable distinction between exact witnesses/history and bounded current semantic views. Contradictions should not be overwritten merely to produce a clean summary. Retrieval should not directly control action. Task-specific context/views can be compiled without materializing the entire history into every decision.

NEAL yielded useful epistemic control: confidence change is observable; contradictions cannot silently become authority; degraded/failure states need explicit terminal semantics; audit lineage belongs to the mechanism, not merely a reporting UI.

Codex Omega contributed useful pressure toward explicit invariants, machine-readable guarantees, cross-disciplinary attack, and refusal of hand-waving.

### What was rejected/narrowed

The old line also accumulated universal claims: hard-coded `optimal` thresholds, branchless-everywhere, thread-per-core, zero-syscall rhetoric, thermodynamic metaphors treated as engineering measurements, grand `Omega/aerospace-grade` labels, and claims that a sophisticated specification implied a sophisticated implementation.

The later forensic work explicitly separated two roles of Codex-like documents:

1. engineering-quality pressure that can constrain generation and verification;
2. persona/rhetorical pressure that may shape model behavior but has no truth authority.

This separation is constitutional for HOSTILE-OS.

### Scar extracted

**Every abstraction and every proof mechanism must pay rent.** `Theoretical maximum` is not a measured property. A local performance tactic is a point in a workload-specific design space, not universal law.

---

## IV. KarnOS / SYNAPSE / KSL / FASM and the direct OS ancestry (early 2026)

KarnOS was the giant architectural explosion of the old machine-sovereignty instinct. Its most durable process idea was:

```text
PROBE -> DERIVE -> EMBODY -> RECURSE
```

The system was supposed to observe actual processor capabilities, cache geometry and other substrate facts, derive implementation parameters, embody a route, and continue adapting rather than hardcode vendor folklore.

It explored cache-line-scale holons, capability dispatch, fixed-point and ternary representations, AVX/scalar routes, heartbeat/ISR machinery, append-only CIL, fault supervision, direct hardware interaction and FASM/KSL.

KSL/FASM asked a genuinely useful question: why should low-level programming surrender all lessons learned by safer languages? The surviving answer is modest but powerful: low-level operations and interfaces can carry **explicit proof obligations, capability requirements and forbidden transitions**. The dead answer is that macros make assembly magically safe.

### Scheduler contamination

KarnOS also explicitly proposed schedulerless/stigmergic coordination. Therefore the current user's intuition that Microseed-like composition might eliminate a dedicated scheduler is **not epistemically fresh**. It is a legitimate hypothesis, but it is ancestry-contaminated.

An earlier Holonix branch, by contrast, retained an ECS-oriented scheduler. Aedifex later retained a deterministic multi-timescale scheduler. Our own ancestry therefore contains serious examples on both sides. The new experiment must discriminate rather than choose a favorite.

### KarnOS/GODSPEC scars

Later hostile archaeology found major overclaims:

- parity/XOR/address binding promoted into security without basis;
- redundant neighbors treated as reconstruction authority without sufficient independent information;
- balanced ternary conflated with physical entropy/storage cost;
- Landauer treated as direct instruction-cost oracle;
- Hilbert locality promoted into security semantics;
- lower instruction count treated as thermodynamic proof;
- labels such as `aerospace grade` treated as assurance;
- drafted functions treated as if implemented/compiled/correct.

These scars are valuable precisely because the architecture was ours. HOSTILE-OS must be hostile to its own attractive ideas before outsiders ever get the chance.

---

## V. Singularity Works / Forge and the birth of the modern research operating system (March-April 2026)

Singularity Works is one of the most important process donors because it crossed the line from theory into an embodied machine.

Its lineage is approximately:

```text
LCC / RALPH bounded controller
 -> LCC v4
 -> Singularity Works forge/control plane
 -> PDVER / Loop+ / shadow documents / labs
 -> HSP
```

The Forge carried Pattern IR, recovery, gates, evidence ledger, assurance rollups, orchestration/runtime, monitoring and controlled transformation. It encoded environment-defined success, stagnation/failure taxonomy, rollback, clean-room recovery, negative constraints, inverse-diff/shadow audit, and project/substrate boundaries.

Research later recognized two equally serious spines:

- Pattern / genome / retrieval / recovery.
- Enforcement / verification / evidence.

This is a direct ancestor of the rule that HOSTILE-OS may never count a clever reconstruction without its assurance/evidence path.

### Methodological evolution

Repeated experience with systems that were declared final and then failed under actual audit produced the modern hostile doctrine:

- build;
- attack;
- isolate failure;
- mutate/strip;
- embody again;
- attack again;
- preserve the scar.

The machine came first in partial form; the methodology generalized from its scars. Eventually research and embodiment became sibling arms rather than sequential stages. OARR became explicit culling. The Semantic Helix became accumulated learning. The Attention Reservoir prevented deep work from erasing neighboring frontiers.

### Scar extracted

`FINAL` is not an evidence state. `Green` is scoped to the discriminator actually tested. Repair is followed by reattack, not celebration.

---

## VI. Ergo-Light / VoidStar / Chainwraith: compact runtime through generative leverage

Ergo/VoidStar/Chainwraith form another critical donor family because they repeatedly attacked the relationship between runtime size and developer/build-time work.

The strongest surviving law is:

> Runtime leverage may be purchased offline.

Expensive discovery, calibration, layout optimization, procedural compilation and code generation may happen outside the final hot runtime if they yield compact deterministic artifacts. The derived artifact must keep provenance to the canonical source/generator/profile.

The project also repeatedly explored memory layout based on actual co-use/access topology instead of conceptual taxonomy, and the idea that logical holon boundaries should not automatically become process boundaries. Isolation is valuable, but serialization/context-switch/coordination cost must be paid for by a real boundary benefit.

### Forensic scars

The later deep linear ledger is especially valuable to HOSTILE-OS because it records concrete low-level failures:

- same cardinality != same topology;
- same vector position != same identity;
- clamping/numeric hygiene can erase domain semantics;
- type alignment != serialized storage alignment;
- unkeyed hash != authentication;
- ignored rollback failure != atomic transaction;
- deterministic control flow != bit-identical floating behavior across hosts;
- a seed embodiment does not erase explicitly retained future scope.

It also identified the dangerous `model mush` pattern: analogy -> enthusiastic restatement -> invented code -> descendant spec cites invention -> later model reads that citation as authority. The new source registry and contamination ledger exist partly to kill that failure mode.

---

## VII. Aedifex-Bellator / Genesis-Omega: developmental authority becomes executable (July 2026)

Aedifex began as a developmental/genomic architecture and matured into an implementation canon with source-bound executable evidence through multiple phases. Its strongest transfer is not biological vocabulary. It is causal separation.

```text
GENOTYPE / GOVERNING RULES
EXPRESSION / ACTIVE REGULATION
PHENOTYPE / WHAT ACTUALLY FORMED
LIFETIME / WHAT WAS LEARNED OR EXPERIENCED
ENVIRONMENT / WHAT ACTUALLY HAPPENED
```

Lifetime learning cannot silently rewrite genotype. Phenotype cannot simply be injected mature. External consequences are environment-authoritative.

When stripped out of biology, this became one of CIC's strongest laws: runtime adaptation may learn facts and calibrations, but it cannot silently rewrite proof semantics, authorization rules, or governing architecture.

Aedifex also made causal authorship explicit: selecting an action and then seeing an expected result does not prove the action caused it. It promoted capability only after identity, interface observation, controlled probe, result observation, limit calibration and evidence.

### Important contrary evidence for HOSTILE-OS

Aedifex's current implementation retained a seeded multi-timescale scheduler and compute-homeostasis allocation in scheduler windows. This is not proof an OS needs a scheduler. It is evidence that explicit scheduling can survive hostile design in another project and therefore deserves a fair comparator.

---

## VIII. FtD distributed organism: ECS/holonic composability becomes operationally concrete (August 2026)

The From the Depths side project is one of the strongest conceptual donors for the current OS because it independently forced a distributed, resource-limited architecture to live inside an alien substrate.

The mature stack explicitly states:

```text
FtD mechanics = physics/hardware substrate
ECS = internal representation
ternary = epistemic state
holons = organizational hierarchy
AFPC-derived logic = resource economy
AI-WMRECS-derived logic = homeostasis
subsumption = local reflex
blackboards/stigmergy = coordination
auctions = task allocation
gossip/predictive coding = asynchronous communication
```

The key structural move was to derive role from present capability instead of static class. A damaged laser craft can cease to be a weapon while remaining useful as sensor, relay or geometry contributor. Multiple damaged survivors can dynamically recombine into a new functional organ.

The deepest efficiency law was not `build a computer in the game`. It was:

> Build the smallest possible computer capable of orchestrating all the computers the substrate is secretly already running for us.

Native detection, targeting, physics, guidance and logistics became accelerators/oracles/actuators rather than things the breadboard logic should reproduce.

### OS transfer pressure

This maps naturally onto hardware, but must be re-derived. The CPU, MMU, interrupt controllers, DMA, storage queues, NIC offloads, timers and GPUs are already computation. A hostile OS should ask what minimal supervisory/compositional machinery is needed to exploit them safely rather than assume every hardware service requires an expansive software civilization.

### Contamination

FtD also explicitly used ECS and holons. Therefore it supports the current intuition but cannot independently validate it.

---

## IX. CIC/NERV: exact authority, requalification and source/runtime separation (August 2026)

CIC/NERV provided some of the most immediately transferable operational scars because its qualification history was tied to real source, runtime and service state.

Key lessons:

- current Git/source identity is read back exactly before mutation;
- source and derived runtime are classified separately;
- deployed configuration and secret authority surfaces are separate from authored source;
- assurance/CSC may inspect the product but does not become runtime authority;
- reboot changes runtime epoch; a historical PID is not current identity;
- a semantic product may become degraded/qualified/unavailable based on live collection authority;
- restoration means recover history then re-probe/requalify, not hydrate `VERIFIED=true` from disk;
- journal growth is a family/resource question; do not jump straight to truncation/rotation before measuring what information CONTROL, REPAIR and AUDIT actually require.

These become direct HOSTILE-OS requirements for device/service registries, caches, persistent state, boot/restart, daemon/service-like phenotypes and kernel audit surfaces.

---

## X. Microseed, TRCH and PAL: composition, bounded commitment and evidence currentness (August 2026)

### Microseed

Microseed is the strongest direct donor for the user's current composability intuition. Its core identity is a tiny prelingual developmental capability organism where useful wholes can compose from existing parts, become externally qualified, be admitted as capabilities, and later serve as parts themselves.

The crucial law is:

`MISSING_BEHAVIOR != MISSING_MECHANISM`.

Before adding a primitive, test composition and rule out representation/binding/authorization/economics/observability/execution/harness failures. Emergent capability is welcome; emergent authority is forbidden.

Applied to an OS, this means `scheduler`, `filesystem`, `process`, `service`, `driver`, and similar nouns are not primitives until reality forces irreducibility.

### TRCH

TRCH showed that rich evidence and relational state can remain graded while a bounded use closes to YES/NO/UNKNOWN. It separated binding, applicability and commitment; derivation, consolidation and reification.

Applied to an OS, a transient probe/derived route need not become permanent global state. Repeated useful qualified derivations may eventually be compiled/materialized.

### PAL

PAL matured provenance/currentness/use-licensing machinery and learned one scar particularly relevant to OS experiments: repeated observations that cannot distinguish two causal candidates do not accumulate into identification evidence. PAL can represent a `DiscriminationNeed` without inventing an executable experiment or hallucinating a hidden object.

Applied here, a clean boot benchmark repeated a thousand times cannot prove a concurrency/security/resource mechanism that the workload never exercises.

---

## XI. Cognitive Field Engineering: representation pressure is not causal depth (August 2026)

CFE/CEF is a candidate field rather than settled canon, but it contributes useful anti-self-deception laws:

- a curator's mechanism name is not automatically the learner/runtime's required ontology;
- surface diversity is not field/causal coverage;
- multi-turn is not automatically long-horizon causal interaction topology;
- long context is not causal depth;
- a compiler/projection layer can dominate the phenomenon and create the appearance it was meant to measure;
- ontology leakage, reification, overload, temporal leakage and paradigm dependence must be attacked.

For HOSTILE-OS this becomes a direct warning against measuring `complexity` by logs, object count or conceptual coverage. A huge component graph can still miss the causal seam; a developer-named `Process` does not prove the substrate needs Process as an ontological primitive.

---

## XII. The conversation that founded HOSTILE-OS (26 August 2026)

The immediate trigger was a discussion of reverse engineering and `cathedral smoke`: the suspicion that beloved software contains a mixture of real irreducible complexity and accumulated historical/organizational sediment.

The first proposed experiment was to take an older open-source operating system and run it through the hostile method. FreeDOS emerged as an attractive scar-rich organism; Linux 0.01 as a small embryonic Unix-like counter-donor. The joke title evolved from `FREE-DOS -> FUCK, WINDOWS AGAIN` to:

`FREE-DOS + LINUX -> FUCK WINDOWS, AGAIN.`

The research question then sharpened:

> What can two competing donors teach us about the minimum sufficient general-purpose operating substrate when neither donor has authority?

The user immediately connected Microseed composition to a provocative scheduler question: perhaps a dedicated scheduler is not irreducible if execution eligibility, authority, resource claims, deadlines and consequence pressure compose sufficiently. That led to the more fundamental intuition:

> An OS should be ECS-like.

The crucial process correction is that this intuition is not new relative to the user's own project history. FtD, Holonix, KarnOS and Cardinal already contain ECS/holonic/capability ideas; KarnOS explicitly contains schedulerless stigmergy. Therefore the project begins with a contamination ledger rather than pretending clean-room personal discovery.

The user then ordered the project to be founded under the existing ProtoAGI research operating system, using every old project as a quarry, and requested the same maximum-depth continuity discipline that had evolved in Microseed/PAL/CIC: a reincarnation package plus a much deeper continuous forensic history preserving every decision/addendum/scar and Commander's Intent.

Finally the user added the supreme architectural constraint:

> Pareto-optimal size/power. Nothing should be larger than it has to be to achieve the goal, relaxed only where it buys genuine capability; size/power is not a single global scalar.

This is now Law 0 of the project constitution.

---

## XIII. Commander’s Intent - current

Build an operating substrate by **re-deriving responsibilities from reality**, not by copying Unix, DOS, Windows, KarnOS, ECS textbooks, or our own favorite abstractions.

Use Linux 0.01 and FreeDOS as competing witnesses. Strip them for mechanisms, invariants, compatibility scars and counterexamples. Let boring mechanisms beat elegant ones. Let old project mechanisms compete, but label contamination and re-earn every transfer.

The target is not minimum LOC and not maximum features. The target is an increasingly capable general-purpose operating environment that remains on a **Pareto frontier of capability versus size/power/burden**, with no single scalar laundering the trade space.

If reality causes familiar mechanisms to grow back, preserve the convergence. If familiar mechanisms disappear, preserve the absence. If an ugly mechanism repeatedly returns after removal, treat that as evidence of a load-bearing scar. If a whole conventional subsystem collapses into existing composable state/transformation/authority/resource mechanisms, do not recreate it for familiarity.

The project succeeds by learning what an operating system actually needs, even if the resulting architecture is strange.

---

## XIV. Current exact authority edge

As of 2026-08-26:

- Project is founded at **Foundation State F0**.
- No HOSTILE-OS implementation is promoted.
- No scientific Pass 1 is claimed.
- Linux 0.01 canonical archive identity and SHA-256 are pinned.
- FreeDOS `ke2046` tag and exact commit are pinned.
- Donor bytes have not been successfully materialized in this ChatGPT runtime, so source-level evidence is not claimed.
- Cross-project quarry and contamination ledgers are established.
- Current campaign cadence: 20-pass bounded slices; each next pass answers the previous pass's discriminator.
- CSC/Genome role: shadow/audit-only, no runtime/veto/enforcement/promotion authority.
- Selected next operation: durably fetch, hash, unpack and qualify both donor source trees on the development machine; inspect launcher logs/status; then begin Pass 1 with responsibility/invariant inventory.

---

## XV. What must never be lost in reincarnation

1. Pareto law is non-scalar and capability-conditioned.
2. The ECS/no-scheduler intuition is live but ancestry-contaminated.
3. Linux 0.01 and FreeDOS are witnesses, not parents.
4. Modern OS solution donors remain sealed until a discriminator earns them.
5. Composition-first is default; conventional nouns have no primitive authority.
6. Exact outcome/currentness/provenance outrank intention/history/narrative.
7. Research, embodiment and assurance remain separate authorities.
8. Every substantive run is durable and post-inspected before evidence counts.
9. Negative evidence, UNKNOWN, rejected branches and scars are durable.
10. The continuous forensic history is a companion authority artifact, not optional prose.

---

## XVI. Founding engineering decision ledger

This section is intentionally redundant with the narrative chronology. The narrative preserves causal continuity; the ledger preserves exact decisions and prevents later replacement threads from smoothing a decision into a vague theme.

### DEC-0001 - Treat the OS project as a scientific re-derivation, not a rewrite hobby

**Trigger:** suspicion that mature software systems contain both load-bearing complexity and historical/organizational sediment (`cathedral smoke`).

**Decision:** the project asks which mechanisms are actually necessary, not how to modernize or prettify an old kernel.

**Rejected framing:** `fix FreeDOS`, `write a Linux clone`, `make a cleaner kernel`, `recreate Windows features`.

**Reason:** those framings grant inherited architecture and product categories authority before the experiment begins.

**Current status:** binding.

### DEC-0002 - Use competing donors instead of one parent lineage

**Trigger:** FreeDOS provides directness/compatibility scars; Linux 0.01 provides a small early Unix-like kernel with a different evolutionary direction.

**Decision:** primary opening donor set is Linux 0.01 + FreeDOS. Neither is the ancestor of HOSTILE-OS.

**Reason:** disagreement between donors is more scientifically valuable than choosing a favorite. Agreement may expose deep constraints; disagreement exposes assumptions worth discriminating.

**Current status:** binding for opening campaigns.

### DEC-0003 - Use Linux 0.01, not contemporary Linux, as the Unix-like opening witness

**Reason:** contemporary Linux contains decades of answers, organizational seams, compatibility, security repairs, hardware scale, and feature growth. Starting there would swamp the experiment with solved architecture and contaminate re-derivation.

**Current status:** binding. Modern Linux is sealed as solution donor until earned.

### DEC-0004 - Use a scar-rich FreeDOS snapshot for the first DOS witness

**Reason:** the experimental asymmetry is useful: embryonic Linux versus mature DOS compatibility. Current FreeDOS carries compatibility and long-horizon scar information that an early DOS-compatible kernel would not.

**Boundary:** this does not claim current FreeDOS is small, optimal, or historically pure. Early FreeDOS genealogy may later become a control if a discriminator requires it.

**Current status:** provisional donor choice pinned to `ke2046`/commit `5ffb5502...245d3`.

### DEC-0005 - Responsibility-first language before subsystem nouns

**Decision:** opening forensic work must describe what the system must accomplish before naming conventional mechanisms.

Instead of `scheduler`, ask: what determines which lawful activity receives finite compute and when?

Instead of `filesystem`, ask: what preserves named/durable information across execution lifetimes and failures?

Instead of `driver`, ask: what safely/economically controls heterogeneous external machinery while containing substrate-specific knowledge?

Instead of `process`, ask: what state/authority/isolation/continuation bundle is required for independent activity?

**Reason:** nouns smuggle historical solutions into the problem statement.

**Current status:** binding opening method.

### DEC-0006 - ECS-like OS is a hypothesis under contamination control

**Trigger:** user's long-running intuition that an OS should be ECS-like; current conversation sharpened it after the no-scheduler thought.

**Decision:** test identity + typed components + transformations/systems + authority/resource control against conventional and hybrid organizations.

**Contamination:** prior Holonic OS/Holonix/FtD/Cardinal/KarnOS work already contains ECS/holonic forms.

**Current status:** live hypothesis; no promotion authority.

### DEC-0007 - A scheduler is not presumed irreducible

**Trigger:** Microseed composition law suggests that execution eligibility, authority, resource claims, deadlines and consequences might compose into most scheduling behavior.

**Decision:** distinguish the physical fact of finite-resource arbitration from the architectural noun `scheduler`.

**Competing candidates:** dedicated scheduler, composed arbitration, conditional scheduler phenotypes, decomposition of the scheduler noun into several independent mechanisms.

**Contrary ancestry:** Holonix/Aedifex retained schedulers; KarnOS proposed schedulerless stigmergy.

**Current status:** open discriminator, heavily ancestry-contaminated.

### DEC-0008 - Prior projects are a quarry, never internal authorities

**Trigger:** explicit Commander order to deep-dive all projects and scavenge relevant laws/processes/systems/scars.

**Decision:** every project may donate ore, including failed/grandiose/obsolete ones. Transfers are classified and re-derived.

**Reason:** there is too much accumulated computational/engineering work to ignore, but importing whole architectures would destroy the experiment.

**Current status:** binding.

### DEC-0009 - Pareto-optimal size/power is supreme design law

**Trigger:** Commander addendum during package construction.

**Decision:** no mechanism may be larger/more power-hungry/more complex than required; relaxation requires a genuine capability/guarantee purchase. No global scalar.

**Reason:** `smallest` alone would delete necessary capability; `most capable` alone would excuse bloat. The project needs nondominated trade surfaces.

**Current status:** constitutional Law 0.

### DEC-0010 - Continuity has two required layers

**Trigger:** prior reincarnation packages were not granular enough; Commander explicitly anchored the older request for continuous history, engineering decisions, Commander's Intent and every addendum.

**Decision:** every major checkpoint maintains:

1. compact reincarnation bootloader/current-state package;
2. continuous forensic history preserving causal chronology and decisions.

**Reason:** a state summary can recover `what`, but not reliably recover `why`, rejected alternatives, contamination, or decision scars.

**Current status:** binding artifact doctrine.

### DEC-0011 - No scientific Pass 1 before donor bytes and durable harness are qualified

**Reason:** source identity metadata is not source analysis; an intended run is not a completed run; tool failure must not become invisible evidence.

**Current status:** binding. Foundation F0 is not Pass 1.

---

## XVII. Founding addenda, in order

These addenda are treated as explicit Commander's Intent deltas, not conversational flavor.

### ADD-001 - Linux 0.01 + FreeDOS opening pair

The Commander selected original Linux-0/Linux 0.01 and FreeDOS as the opening donor pair. This superseded the earlier possibility of FreeDOS alone with xv6 as a control. xv6 remains an external control candidate, but it is sealed unless a later discriminator promotes it.

### ADD-002 - Microseed composability may dissolve conventional scheduler architecture

The Commander explicitly proposed stealing Microseed composability rules and questioned whether a scheduler is necessary at all. This does not mandate scheduler elimination. It mandates that scheduler irreducibility be tested rather than inherited.

### ADD-003 - OS should be ECS-like

The Commander identified ECS-like organization as the deeper original intuition. This became a preregistered hypothesis with contamination controls rather than a design decree.

### ADD-004 - Pull FtD and Bellator-Aedifex

The Commander required these two projects be reopened because their architectures are directly relevant. FtD provided capability-derived role, ECS/holonic recomposition, distributed resource economy and native-substrate orchestration. Aedifex provided causal layer separation, developmental capability admission, authorship, and a contrary scheduler witness.

### ADD-005 - Use the ProtoAGI project folder/corpus and reread project memories

The Commander explicitly required the project to use the ProtoAGI project context/corpus rather than rely on the local conversation alone. This instruction is permanent for continuity work: project archaeology is a normal part of Loop+ breadth, especially before new primitives or when lineage is unclear.

### ADD-006 - Reconstruct the older continuous-history request and include it with reincarnation

The quoted anchor - extract a continuous history/engineering decisions/Commander's Intent/every addendum across the ProtoAGI project - was recovered as the ancestor of the modern continuous forensic reincarnation artifact. This document is the direct HOSTILE-OS embodiment of that rule.

### ADD-007 - Pareto-optimal size/power, explicitly non-scalar

The Commander added the supreme design constraint while the foundation package was being built. It must not be misread later as `minimize bytes` or `minimize energy`. Capability, size, energy, latency, privilege, failure surface and other burdens form a partial order.

### ADD-008 - Deep-dive all projects, not only the obvious four

The Commander explicitly warned that old work is `a lot of computer on the table to scavenge`. This widened the quarry to CogOS, Codex Omega, CIL/Quipu/RuneFlow, NEXUS, TacSim, PCMMAD, Cardinal, MRSS/RPF, Z80/TQ2, CFE, the direct-hardware 2024 seed and the mature Forge/HSP/CSC line - in addition to FtD, Aedifex, KarnOS, Microseed, PAL/TRCH, CIC and Ergo.

---

## XVIII. The process genealogy that HOSTILE-OS inherits

The project process did not spring into existence as a polished HSP diagram. It was earned by repeated failures of shallower workflows.

### Phase A - iterative co-engineering under mature physical constraints

MRSS demonstrated the useful core of human/model cooperative iteration when the problem had mature external physics and mathematics. The human supplied boundary conditions and verification pressure; AI supplied breadth, candidate architectures and iteration throughput. The important lesson was not the magnetic device. It was that rapid iteration becomes useful when **external constraint quality is high**.

Failure boundary: multiple models agreeing does not transform their agreement into physical evidence.

### Phase B - grand architecture/specification era

NEAL/IW-CO/CogOS/Codex/KarnOS produced enormous conceptual breadth quickly. This era generated real mechanism candidates but also proved that models can recursively certify attractive stories. A spec can acquire internal consistency while remaining physically or computationally wrong.

Failure boundary: coherent documents are not embodiments.

### Phase C - Forge / controlled transformation

Singularity Works turned some of the accumulated doctrine into executable recovery, pattern, transformation, gate and evidence machinery. Environment-defined success and controlled remediation made external outcomes harder to narrate away.

Failure boundary: an assurance machine can itself be wrong or ceremonial.

### Phase D - PDVER / research-embodiment sibling arms

The workflow shifted from `research then build` to a topology in which research and embodiment both generate evidence after an initial reality gate. Embodiment becomes a way to make abstract claims vulnerable to new research rather than a final stage after theory is complete.

### Phase E - HSP / Loop+ / OARR / Helix / Reservoir

HSP generalized the whole workflow:

- Loop+ keeps search broad and hunts isomorphs, boring comparators and negative space.
- OARR forces a local discriminator and hostile evidence change.
- PDVER ties research and embodiment back to reality.
- Semantic Helix preserves positive and negative learning without inheriting confidence.
- Attention Reservoir preserves nearby fronts and prevents local depth from pretending to be global completeness.
- CSC/Genome supplies an independent audit surface but remains non-sovereign.

### Phase F - bounded campaign slices and durable launch discipline

Long campaigns exposed two new process failure modes: rabbit holes and non-recoverable execution. Campaigns therefore became bounded slices. Later global continuity set the default at 20 passes per slice. Separately, naive foreground launchers were banned: a crashed shell or missing log must never leave us unsure whether a scientific run happened.

HOSTILE-OS begins after these lessons were already earned. It does not get to regress to ad-hoc `try code and see` merely because OS work is exciting.

---

## XIX. Why Pareto-optimal size/power is not a slogan

The new supreme law unifies several older project scars without importing their bad metrics.

### 1. From CogOS: whole-system coupling

CPU optimization can free thermal/power headroom for another accelerator. Conversely, a local low-latency busy-spin can dominate energy and thermal budget. Therefore optimization must be evaluated at the whole relevant resource envelope.

### 2. From Ergo: asymmetric resource spending

A large offline compiler/search/calibration step may buy a tiny runtime. That can be Pareto-superior for deployment even if total development compute rises sharply. `Size` must name the scope being optimized.

### 3. From FtD: don't pay twice for substrate computation

If hardware already provides a qualified operation, reproducing it in software may be dominated. But the software may still need validation, authority, recovery or abstraction around it. The question is how much wrapper buys genuine capability.

### 4. From Rust ECS audits: locality can dominate elegance

A theoretically small generic representation can be slower/larger in cache traffic than a specialized layout. Conversely, many specialized object types can bloat code and metadata. Hybrid layouts are legitimate nondominated candidates.

### 5. From CIL/CIC: evidence itself has a resource economy

Append-only history preserves audit/repair value but can grow without bound. Deleting history saves bytes but can destroy repair/provenance. The Pareto question is purpose-relative: what evidence must exist for CONTROL, REPAIR and AUDIT, and what representation retains it at minimum burden?

### 6. From KSL/Codex: proof has a cost

A proof obligation can reduce runtime checks and failure risk, but a universal proof layer can create enormous authoring/compile/complexity burden. Some properties are best discharged statically; residual runtime checks remain where facts are dynamic. Assurance itself belongs on the frontier.

### Required discipline

When later developers say `X is smaller`, they must state **smaller in which dimensions and at what capability loss/gain**. When they say `X is more powerful`, they must state what qualified capability was bought and what burden increased.

---

## XX. Scheduler question - forensic framing before implementation

The scheduler discussion is a perfect example of why responsibility-first language and contamination control matter.

### Physical constraints that cannot be hand-waved away

At minimum, a finite machine can face:

- multiple progressable activities and fewer execution resources;
- blocked and newly-unblocked activities;
- deadlines and latency sensitivity;
- malicious or accidental monopolization;
- resource dependencies and priority inversion-like structures;
- multicore/cache/coherency effects;
- energy and thermal ceilings;
- I/O completion and interrupt/event pressure;
- fairness/starvation requirements that may or may not be part of the use contract.

Something must determine what advances.

### What is not yet established

It is not established that the determining mechanism must be a centralized/dedicated `scheduler` object with its own permanent policy civilization.

A candidate compositional decomposition could include:

```text
eligibility/currentness
+ authority
+ resource claims
+ dependency readiness
+ deadlines/urgency
+ viability/homeostatic pressure
+ bounded arbitration among remaining conflicts
```

But the decomposition may simply hide a scheduler under different nouns. Hostile tests must detect that form of semantic laundering.

### Fair comparator requirement

The dedicated scheduler candidate gets to be good. It may be tiny, well-specified and workload-adaptive. The composed candidate does not get to beat a strawman scheduler.

Likewise, a schedulerless route that depends on every component busy-polling or broadcasting may lose on power/coherency even if it deletes scheduler code.

This is exactly why the Pareto frontier must include energy, synchronization and failure surface rather than LOC alone.

---

## XXI. ECS-like OS question - forensic framing before implementation

The intuition is that conventional OS nouns may be phenotypes composed from state rather than primitive classes.

Possible examples, purely as candidate decompositions:

```text
traditional process-like phenotype
= execution state
+ address/memory state
+ authority
+ resource claims
+ continuation/lifecycle
+ observation/debug surface

traditional file-like phenotype
= durable byte/content state
+ namespace/binding
+ authority
+ persistence/recovery semantics

traditional endpoint-like phenotype
= transport state
+ address/binding
+ queues/buffers
+ authority
+ readiness/event state
```

These examples are not architecture. They illustrate the discriminator: can shared components/transforms reduce duplication and improve composition without creating worse synchronization, locality, verification or security?

### Reasons ECS-like representation might win

- capability/role can change without class migration/reconstruction;
- systems can operate over precisely typed state subsets;
- SoA/data-oriented layouts can improve traversal locality for hot homogeneous state;
- shared lifecycle/currentness/authority components may avoid subsystem-specific copies of the same concept;
- composition can produce new phenotypes without adding a new privileged subsystem.

### Reasons it might lose

- dynamic component sets can fragment locality or create metadata overhead;
- generic queries can hide expensive scans;
- system-wide component access can create terrifying mutation authority;
- concurrency/ownership semantics may become harder than specialized structures;
- security boundaries do not naturally follow ECS query boundaries;
- some state has specialized algorithms/data structures that generic ECS storage would distort;
- code size can shrink while runtime indirection and verification surface grow.

Therefore the strongest live hypothesis is not `everything is ECS`. It is that **ECS-like typed state/composition may be one substrate among specialized representations, selected where it sits on the Pareto frontier**.

---

## XXII. Historical scars converted into explicit HOSTILE-OS attack fixtures

The following are not merely prose warnings. Later campaigns should turn them into tests where applicable.

### SCAR-FIXTURE-01 - identity/index confusion

Construct two entities/resources that exchange storage positions while identity must remain stable. Reject implementations where vector/index position becomes identity accidentally.

### SCAR-FIXTURE-02 - cardinality/topology confusion

Construct equal-size structures with different connectivity/ordering semantics. Reject compression/equivalence logic that treats equal element count as structural identity.

### SCAR-FIXTURE-03 - stale currentness after reboot

Persist a previously qualified device/service/capability, reboot/change substrate, and verify history restores without operational authority until re-probe/requalification.

### SCAR-FIXTURE-04 - rollback failure

Inject a failure during recovery/rollback itself. Reject mechanisms that report transactional success because rollback was attempted.

### SCAR-FIXTURE-05 - hash/authentication confusion

Corrupt or adversarially substitute data under an integrity-only scheme. Verify integrity and authenticity claims remain separate.

### SCAR-FIXTURE-06 - nondiscriminating repetition

Run many repetitions that cannot distinguish candidate mechanisms. Verify confidence/completeness does not increase merely from sample count.

### SCAR-FIXTURE-07 - abstraction rent

Replace a generic abstraction with direct/specialized mechanism and vice versa under the same capability contract. Record full Pareto vector; do not promote either based on aesthetics.

### SCAR-FIXTURE-08 - assurance false green / false veto

Give CSC/checkers a known-good, known-bad, near-miss and false-positive trap. If the checker cannot discriminate, its result has no promotion authority.

### SCAR-FIXTURE-09 - environment authority

Create expected action success but force a different actual external result. Verify model/intent/log expectation does not overwrite actual consequence.

### SCAR-FIXTURE-10 - compatibility scar deletion

Remove an ugly donor behavior believed to be sediment, then run the exact workload/contract that historically depends on it. Preserve if it carries reality; remove only after the contract is deliberately rejected or replaced.

---

## XXIII. Authority boundaries between HOSTILE-OS and old projects

Old projects fall into four operating roles.

### A. Governing-process donors

HSP, Loop+, OARR, PDVER, Helix, Reservoir, current CSC/Genome, durable-launch/archive doctrine. These are process law unless superseded explicitly.

### B. Mechanism/scar quarries

FtD, Aedifex, Microseed, PAL, TRCH, CIC, Forge, Ergo/VoidStar/Chainwraith, Rust ECS audit, CogOS, CFE, CIL/Quipu/RuneFlow, NEXUS, TacSim, PCMMAD, Cardinal, Z80/TQ2, MRSS/RPF.

They may inspire candidates and attack fixtures. They do not set HOSTILE-OS ontology.

### C. Heavy contamination donors

Holonic OS/Holonix/KarnOS/KSL/GODSPEC and the 2024-25 direct-hardware OS seed. These already contain close relatives of the live OS hypotheses. They are explicitly recorded so future convergence is not misrepresented.

### D. Sealed external comparison vault

Modern OS families and external architecture research remain sealed during opening derivation unless the live discriminator promotes them. This is not anti-research dogma; it is an experimental contamination boundary.

---

## XXIV. Continuity artifact doctrine - exact translation of the older anchor

The Commander's old request for a continuous history was translated over repeated project failures into the following durable rule.

### The reincarnation bootloader answers

- What is the exact current state?
- What authority wins if sources conflict?
- What is Commander's Intent?
- What is the selected frontier?
- What is the exact next lawful operation?
- What mechanisms/laws must never silently return or disappear?

### The continuous forensic history answers

- How did this state arise?
- What did the Commander correct and when?
- Which design alternatives were live at each fork?
- Why was a mechanism rejected/narrowed/deferred?
- What failure earned each scar/law?
- Which project/source actually originated a mechanism?
- Is apparent convergence independent, descendant restatement, or ancestry-contaminated?
- What addenda changed the project constitution or research direction?
- What parts of prior handoffs were later superseded?

### Required update triggers

Update the continuous history whenever any of the following changes materially:

- Commander's Intent or supreme constraints;
- donor set or source authority;
- campaign/process law;
- primitive/architecture admission or rejection;
- major mechanism promotion/demotion;
- new scar or generalized failure boundary;
- contamination classification;
- code lineage/authorship ownership;
- assurance role/authority;
- sealed/deferred branch status;
- exact frontier or reason for route switch.

A routine test result belongs in campaign evidence. A test result that changes why the project believes something belongs here too.

---

## XXV. Archive/packaging doctrine inherited from ProtoAGI

When HOSTILE-OS artifacts grow large:

- canonical package is built and verified before splitting;
- SHA-256 manifest covers every payload;
- archive closure is tested from a fresh extraction;
- default split ceiling is 200,000,000 bytes unless platform constraints require smaller;
- include reassembly helper and hashes;
- never count an archive as valid merely because compression completed;
- exact file lineage and source/generated/derived boundaries remain explicit.

This founding package is far below split size, but the rule is recorded before need arises so packaging pressure cannot rewrite provenance later.

---

## XXVI. Current unresolved seams

These are not omissions to be silently filled. They are explicit UNKNOWN/frontier state.

1. **Exact development host/toolchain** for first donor builds/emulation is not yet captured in this package.
2. **Linux 0.01 build/boot path on the selected modern emulator/toolchain** is not yet qualified.
3. **FreeDOS `ke2046` build/boot baseline** is not yet qualified in the selected environment.
4. **FreeDOS donor choice** is rationally pinned as scar-rich current witness, but early-FreeDOS genealogy remains an open control candidate.
5. **Responsibility inventory schema** is preregistered conceptually but has not yet been populated from source/runtime observation.
6. **Scheduler irreducibility** is UNKNOWN.
7. **ECS-like organization Pareto superiority** is UNKNOWN.
8. **Authority primitive shape** is UNKNOWN.
9. **Persistence namespace/object semantics** are UNKNOWN.
10. **Driver/device-boundary shape** is UNKNOWN.
11. **Compatibility placement** (core vs boundary/adapters vs generated layer) is UNKNOWN.
12. **Multicore evolution strategy** is UNKNOWN and must not be imported from modern kernels early.
13. **Security model** is UNKNOWN beyond the requirement that authority be explicit/current/bounded.
14. **Energy measurement method** for early emulation campaigns is not yet selected; proxy vs physical measurement must remain distinguished.
15. **Project final name** is provisional; motto is not automatically the repository/product name.

---

## XXVII. Exact stop point / next operation

Stop point at package construction:

```text
FOUNDATION F0
cross-project quarry: established
constitution: established
Pareto law: established
contamination ledger: established
Linux 0.01 identity/hash: pinned
FreeDOS tag/commit: pinned
local donor bytes: NOT QUALIFIED HERE
scientific passes earned: 0
```

Next operation is **not architecture design**.

It is:

```text
run durable donor acquisition
-> verify Linux SHA-256
-> verify FreeDOS exact commit/tree
-> preserve immutable donor source trees
-> capture build/emulation toolchain + environment
-> establish donor baseline behavior
-> inspect logs/status
-> only then begin Campaign 001 Pass 1
```

Pass 1 then asks the responsibility-first question already preregistered. Whatever it discovers determines Pass 2. No 20-pass itinerary is pre-authorized.
