# Constitution and Governing Laws

**Project:** HOSTILE-OS (provisional working name)  
**Founded:** 2026-08-26  
**Campaign motto:** `FREE-DOS + LINUX -> FUCK WINDOWS, AGAIN.`  

## 0. Supreme design constraint: Pareto-optimal size/power subject to required capability

The operating system shall pursue a Pareto frontier over **capability and burden**, not a single global score.

No mechanism, abstraction, privilege boundary, cache, daemon, scheduler, metadata layer, compatibility shim, background worker, proof mechanism, or convenience subsystem may be larger, hotter, slower, more stateful, more privileged, or more conceptually expensive than necessary to satisfy its qualified purpose.

A larger point on the design frontier is admissible only when the extra burden buys a **real and evidenced capability** or a necessary nonfunctional property such as safety, robustness, compatibility, recoverability, determinism, observability, or bounded latency that the smaller point cannot provide.

The project shall not collapse this into a scalar such as LOC, binary size, RAM, throughput, joules, latency, syscall count, process count, or benchmark score. Candidate mechanisms are compared by partial order over a burden/capability vector.

Default burden vector:

- executable/image bytes;
- resident and peak memory;
- persistent state and metadata burden;
- cycles and throughput cost;
- latency and jitter;
- energy and thermal pressure;
- cache/memory-bandwidth pressure;
- privileged attack surface;
- dependency surface;
- independent concept/primitive count;
- synchronization/coherency burden;
- failure and recovery surface;
- verification/assurance burden;
- compatibility burden;
- operational/maintenance burden.

Capability vector is purpose-specific and may include useful work, isolation, persistence, deadline satisfaction, device support, fault tolerance, recovery, security, deterministic replay, compatibility, observability, and compositional leverage.

**Law P0:** A design may be nondominated without being globally best. Task context may lawfully select among nondominated points; no universal optimizer is presumed.

**Law P1:** A local optimization that worsens the whole-system frontier may be rejected. Examples: CPU busy-spin that improves latency but wastes energy/thermal budget; GPU offload that increases transfer/VRAM pressure; microservice isolation that adds serialization/process overhead; compression that destroys useful semantics; formal assurance whose runtime burden exceeds the risk it controls.

**Law P2:** Every abstraction pays rent. The rent is a discriminator-backed capability or guarantee, not rhetorical cleanliness.

## 1. Highest-priority transfer law

> Steal mechanisms, not abstractions.  
> Steal invariants, not architectures.  
> Steal scars, not dogma.

No donor - Linux, FreeDOS, Windows history, BSD, KarnOS, Holonix, Microseed, FtD, Aedifex, CIC, PAL, TRCH, Forge, Ergo, external research, or this project's own previous pass - receives ancestry privilege.

Default transfer cycle:

```text
isomorphic hunt
-> mechanism recognition
-> strip project-specific nouns
-> isolate invariant / scar / counterexample
-> propose candidate transfer
-> hostile re-derivation in OS conditions
-> embody
-> attack again
-> promote narrowly or kill
```

## 2. Composition-first law

`MISSING_BEHAVIOR != MISSING_MECHANISM`.

Before creating a new primitive or subsystem:

1. localize the actual failure;
2. test whether existing state/components/capabilities can compose into the required behavior;
3. exclude representation, binding, authority, currentness, economics, observability, execution, and harness defects;
4. attack plausible compositions;
5. add only the smallest missing distinction if irreducibility is earned.

A named problem never authorizes a named manager. Do not create `Scheduler`, `ProcessManager`, `ReentryManager`, `ArbitrationManager`, `UncertaintyEngine`, `GoalManager`, `ServiceManager`, or similar merely because the noun is conventional.

## 3. ECS-like ontology is a hypothesis, not a foregone conclusion

The live hypothesis is that many traditional OS objects may be recurring component/capability bundles rather than privileged ontological species. Candidate formulation:

```text
identity + typed components + qualified transformations + authority + resource arbitration
```

This is **ancestry-contaminated** by prior FtD, Holonix, KarnOS, Cardinal and Microseed work. Therefore it must be re-earned under the Linux 0.01 / FreeDOS donor experiment. We may call convergence *re-derived*, not independent of our own ancestry.

## 4. Authority and epistemic laws

- Emergent capability is allowed; emergent authority is not.
- Confirmed semantic intent is not execution authority.
- Execution authority is consequence-side, current, and referent-bound.
- Fallback behavior requires its own authority and safety qualification.
- Attempted != established != observed != acknowledged.
- Partial success remains partial.
- Observation != inference != hypothesis != derived assessment != permission.
- Historical qualification does not grant current qualification.
- Local capability does not imply global authority.
- UNKNOWN is a first-class state when the evidence is insufficient.
- Confidence/reliability/currentness/provenance are distinct dimensions.
- More observations from a nondiscriminating regime do not resolve an identification problem.
- A hostile alternative need not be proven true to defeat an exhaustive claim; its live possibility can withdraw universal license.

## 5. Currentness and restoration laws

- Runtime history is not current reality.
- Restoration may recover history/identity, not silently restore current capability.
- Re-entry path: historical continuity -> probe actual substrate -> bind -> observe -> qualify -> verify -> promote -> authorize.
- No mature-state injection from disk, snapshot, package, cached device graph, service record, old PID, prior topology, or stale capability registry.
- Currentness should be earned by challenge/shielding/censoring/qualified evidence/use contract, not arbitrary elapsed-time decay.

## 6. Aedifex-derived causal separation

Keep separate:

```text
CONSTITUTION / GOVERNANCE
EXPRESSION / ACTIVE CONFIGURATION
PHENOTYPE / CURRENTLY FORMED CAPABILITIES
LIFETIME / HISTORY + LEARNED/CALIBRATED STATE
SUBSTRATE / EXTERNAL MACHINE REALITY
```

Runtime adaptation may not silently rewrite constitutional semantics, proof rules, authorization rules, or project law. Structural mutation requires an explicit change-authority path and new verification burden.

## 7. Provenance and lineage laws

- Source IDs, event IDs, commit IDs, model names, or distinct paths do not by themselves establish independence.
- Descendant restatement is not independent corroboration.
- Same shape across projects earns a discriminator, not a merged identity.
- Every promoted mechanism carries origin, competing alternatives, attacks survived, failures, boundary conditions, and current authority.
- Exact source bytes/hashes/trees/logs outrank narrative memory when they conflict.

## 8. Assurance law

CSC/Genome-style assurance is **audit-only by default**. It has no automatic veto, enforcement, promotion, runtime, or production authority.

The checker must earn the right to check through:

- known-good;
- known-bad;
- legal near-miss;
- false-positive trap;
- applicability discrimination;
- target/profile recognition;
- lineage/coverage ceiling.

No ceremonial assurance layer survives if it does not add independent discrimination or evidence quality.

## 9. Research operating system

HSP governs the work:

```text
IDEA
 -> Loop+ breadth/problem expansion
 -> OARR named discriminator/adversarial culling
 -> PDVER reality contact
 -> Research Arm and/or Embodiment Arm
 -> shared evidence
 -> Semantic Helix
 -> Attention Reservoir
 -> next bounded pass
```

Roles remain separate:

- Loop+: breadth/search; no promotion authority.
- OARR: bounded hostile discriminator; no quiet Pass 6 inside a local slice.
- PDVER: Probe -> Derive -> Embody/Verify -> Recurse reality-contact metabolism.
- Helix: accumulated evidence/scars; inherits evidence, not confidence.
- Attention Reservoir: preserves deferred/open frontiers and fights rabbit holes.
- CSC: assurance peer, audit-only unless separately earned.

## 10. Campaign cadence

For this project, the current global rule is **bounded 20-pass campaign slices**. This supersedes older 25-pass envelopes preserved in some ancestry artifacts unless the Commander explicitly changes cadence.

Every pass:

1. begins from the exact question/discriminator exposed by the previous pass;
2. performs one recoverable evidence operation or tightly coupled deterministic mini-batch;
3. persists raw result/log/evidence;
4. records evidence-state change and assurance ceiling;
5. performs an Attention Reservoir breadth check;
6. derives the next question;
7. hard-stops after Pass 20 for campaign reconciliation.

## 11. Durable execution and artifact law

No naive foreground scientific launch.

Every substantive run must record:

- explicit working directory;
- environment/PYTHONPATH/toolchain identity;
- source/donor commit/hash identity;
- start/end timestamps;
- stdout + stderr;
- PID when relevant;
- exit code;
- completion marker/receipt;
- result artifact hashes.

Logs and exit status are inspected **after** the run before evidence counts.

Every artifact - prose, code, script, config, command, test, verifier, archive - is itself hostile-engineered before reliance.

## 12. Code lineage and authorship

- Inspect live code before implementing a mechanism that may already exist.
- Preserve coherent authorship style and module boundaries where they remain useful.
- Never reimplement silently because conversational context forgot an ancestor.
- New implementation must name its lineage/ownership and why it exists.
- Promotion requires exact source state plus test/log evidence.

## 13. Anti-toy / whole-system law

Small worlds and harnesses are valid only when they preserve the causal contract under test. A toy is not allowed to create success by removing the hard part.

Eventually every promoted core mechanism must face end-goal-bearing integrated pressure: concurrent work, hostile/malformed workloads, resource scarcity, device failure, restart, persistence, compatibility, partitions, deadlines, multicore, security boundaries, and long-horizon operation.

## 14. Anti-clock law

No elapsed-time decay as epistemology by default. Time is evidence only when the underlying mechanism makes it relevant (lease, deadline, hardware timeout, freshness contract, physics, protocol, etc.).

## 15. External consequence sovereignty

The machine/substrate/environment determines what happened. Our model, scheduler hypothesis, logs, emulation, tests, or expected state do not outrank actual consequence.

## 16. Failure assimilation

A sufficiently understood failure must leave a durable scar that changes future search/test pressure. Fix -> reattack -> new evidence. `FINAL` and `SEALED` are artifact states, not evidence states.

## 17. Capability density

A useful derived metric family - never sovereign - is capability density:

```text
earned useful capability
----------------------------------------------
bytes + energy + latency + concepts + privilege + failure surface
```

Use it to expose dominated designs, not to collapse incomparable properties into one false number.
