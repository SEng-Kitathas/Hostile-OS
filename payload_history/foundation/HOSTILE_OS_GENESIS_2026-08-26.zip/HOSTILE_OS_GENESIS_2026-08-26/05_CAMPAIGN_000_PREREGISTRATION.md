# Campaign 000 Preregistration - Founding Quarry and Donor Qualification

**Status:** FOUNDATION ONLY. No scientific OS pass has yet been earned.  
**Why:** primary donor identities are pinned but donor bytes have not been durably fetched, hashed, unpacked, built/emulated, and logged in the development environment.

## Campaign 001-020 live question

> What is the smallest set of mechanisms required for increasingly capable general-purpose operating behavior when Linux 0.01 and FreeDOS are competing witnesses, and no conventional subsystem noun is granted primitive status in advance?

## Opening discriminator

Before asking whether an OS needs a scheduler, filesystem, process model, driver model, service manager, or other inherited noun, establish a **responsibility inventory** directly from donor behavior and source.

Pass 1 target question:

> What externally observable responsibilities and invariants are actually carried by the two donor kernels at boot and during the smallest useful execution workload, without naming the implementation subsystems that carry them?

## Required preconditions before Pass 1 counts

1. Linux 0.01 bytes match the kernel.org SHA-256.
2. FreeDOS repository snapshot resolves exactly to commit `5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3`; snapshot hash is recorded locally.
3. Both donor source trees are immutable/read-only in `donors/`.
4. Build/emulation toolchain identity is captured.
5. Durable launcher produces start/end timestamps, cwd, environment, stdout/stderr, exit status and completion receipt.
6. A clean baseline boot/run is demonstrated for every donor that can be made runnable in the selected emulator/toolchain; inability is recorded as evidence, not hidden.
7. No modern comparison OS source has entered the design context during opening derivation.

## Initial 20-pass envelope - adaptive, not prewritten itinerary

Only Pass 1 is concretely specified. Passes 2-20 are placeholders and MUST be derived from the question exposed by the preceding pass.

- P01: donor responsibility/invariant inventory under minimal boot/use workload.
- P02-P20: `DERIVE_FROM_PREVIOUS_PASS`; no itinerary authority.

The envelope may include comparison, ablation, mutation, fault injection, or minimal reconstruction only when the live discriminator earns it.

## Required per-pass record

```text
PASS ID
incoming question/discriminator
current authority/source hashes
operation performed
raw artifact/log path
result
positive evidence
negative evidence
UNKNOWN/debt
candidate mechanisms affected
Pareto vector delta (if any)
assurance ceiling
Attention Reservoir breadth check
next question
```

## Pareto pre-registration

No candidate wins because it is smallest or fastest alone. For every materially different candidate, capture enough of the following to expose dominance:

- code/data bytes attributable to mechanism;
- resident/peak memory;
- cycles or workload time;
- latency/jitter where relevant;
- energy proxy / power / thermal where measurable;
- synchronization/coherency traffic;
- privileged surface;
- dependency count/surface;
- state/metadata volume;
- concept/primitive count;
- failure/recovery modes;
- capabilities/guarantees passed;
- compatibility burden.

Do not sum these into one global score.

## Scheduler hypothesis preregistration

Hypothesis S0: a dedicated scheduler is irreducible.  
Hypothesis S1: scheduling responsibilities compose from eligibility/currentness/authority/resource/deadline mechanisms plus a small arbitration primitive.  
Hypothesis S2: multiple scheduler phenotypes are conditionally materialized by workload/substrate.  
Hypothesis S3: the word `scheduler` conflates several mechanisms that should remain separate.

**Contamination warning:** S1 resembles old KarnOS/Microseed/FtD intuition. None is privileged.

Discriminator cannot be chosen by aesthetic elegance. It must include at minimum contention, starvation pressure, deadlines/interactive latency, blocked/unblocked work, adversarial CPU consumption, multicore/coherency, priority inversion or equivalent resource dependency, and energy/thermal cost when the candidate reaches that frontier.

## ECS hypothesis preregistration

E0: conventional object taxonomy is necessary for correctness/clarity/performance.  
E1: identity + typed components + systems/transformations can express the required state more compactly.  
E2: hybrid organization is Pareto-superior: some state fits ECS-like tables while other state needs specialized structures.  
E3: ECS-like representation works functionally but loses on security, synchronization, locality, or verification burden.

Again, E1 is ancestry-contaminated; the experiment can validate it but not manufacture personal novelty.

## First hostile comparator rule

Every clever mechanism gets a boring comparator under the same workload/resource ceiling. Examples: simple queue vs stigmergic arbitration; specialized struct vs generic component table; static mapping vs adaptive probing; direct call vs message/event path; bounded ring vs append-only journal.

If boring wins, boring is promoted.
