# Thread Redline Protocol

At every substantive project reply or campaign checkpoint, silently verify:

- CURRENT: exact authority edge, donor/source hashes, pass/campaign state.
- COMMANDER'S INTENT: what end-state and constraints govern.
- TARGET: proposition/change actually at stake.
- DISTINCTIONS: what must not be collapsed.
- ALTERNATIVES: at least the strongest boring/hostile rival.
- DISCRIMINATOR: what observation would change the decision.
- ACTION: smallest operation with useful information gain.
- EVIDENCE DELTA: what materially changed.
- PARETO DELTA: what burden/capability dimensions changed; no scalar laundering.
- ASSURANCE CEILING: what still cannot be claimed.
- SCARS: new negative evidence/failure boundaries.
- CONTAMINATION: did ancestry influence the candidate or claim of novelty?
- RESERVOIR: what neighboring/frontier question must remain visible.
- NEXT: exact next lawful operation.

If evidence did not change, do not count a pass. Route-switch, broaden, or stop.

Every meaningful checkpoint updates both:
1. compact reincarnation state;
2. continuous forensic history when a decision/addendum/scar/authority boundary changed.
