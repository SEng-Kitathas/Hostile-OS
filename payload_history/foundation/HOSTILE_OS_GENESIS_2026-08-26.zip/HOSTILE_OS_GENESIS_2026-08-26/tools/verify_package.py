#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parents[1]
manifest_path = root / "MANIFEST.json"
EXCLUDED = {"MANIFEST.json", "SHA256SUMS"}

if not manifest_path.exists():
    print("FAIL: MANIFEST.json missing")
    sys.exit(2)

try:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"FAIL: cannot parse MANIFEST.json: {exc}")
    sys.exit(2)

items = manifest.get("files")
if not isinstance(items, list):
    print("FAIL: manifest files is not a list")
    sys.exit(2)

errors = []
listed = set()
for item in items:
    rel = item.get("path")
    if not isinstance(rel, str) or not rel or rel.startswith("/") or ".." in Path(rel).parts:
        errors.append(f"invalid manifest path {rel!r}")
        continue
    if rel in EXCLUDED:
        errors.append(f"excluded control file listed as payload: {rel}")
        continue
    if rel in listed:
        errors.append(f"duplicate manifest entry: {rel}")
        continue
    listed.add(rel)
    p = root / rel
    if not p.is_file():
        errors.append(f"missing {rel}")
        continue
    data = p.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    if sha != item.get("sha256"):
        errors.append(f"hash {rel} expected {item.get('sha256')} got {sha}")
    if len(data) != item.get("bytes"):
        errors.append(f"size {rel} expected {item.get('bytes')} got {len(data)}")

actual = {
    p.relative_to(root).as_posix()
    for p in root.rglob("*")
    if p.is_file() and p.relative_to(root).as_posix() not in EXCLUDED
}
for rel in sorted(actual - listed):
    errors.append(f"unmanifested payload file: {rel}")
for rel in sorted(listed - actual):
    errors.append(f"manifest entry has no payload file: {rel}")

if errors:
    print("FAIL")
    for err in errors:
        print(err)
    sys.exit(1)

print(f"PASS: exact package closure; {len(listed)} payload files verified")
