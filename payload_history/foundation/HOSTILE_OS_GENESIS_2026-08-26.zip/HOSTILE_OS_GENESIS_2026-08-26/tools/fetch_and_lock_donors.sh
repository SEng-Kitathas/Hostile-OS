#!/usr/bin/env bash
set -Eeuo pipefail

# HOSTILE-OS durable donor acquisition / lock wrapper.
# Run from the package root on a development machine with curl, git, tar, sha256sum.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
LOG_DIR="$ROOT/logs"
DONOR_DIR="$ROOT/donors"
RECEIPT="$LOG_DIR/donor_lock_${RUN_ID}.receipt"
LOG="$LOG_DIR/donor_lock_${RUN_ID}.log"
mkdir -p "$LOG_DIR" "$DONOR_DIR"

LINUX_URL='https://www.kernel.org/pub/linux/kernel/Historic/linux-0.01.tar.gz'
LINUX_SHA='24454f830cdb571e2c4ad15481119c43b3cafd48dd869a9b2945d1036d1dc68d'
FDOS_REPO='https://github.com/FDOS/kernel.git'
FDOS_COMMIT='5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3'

exec > >(tee -a "$LOG") 2>&1
START="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
RC=0
finish() {
  RC=$?
  END="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  {
    echo "run_id=$RUN_ID"
    echo "start_utc=$START"
    echo "end_utc=$END"
    echo "cwd=$ROOT"
    echo "exit_code=$RC"
    echo "linux_expected_sha256=$LINUX_SHA"
    echo "freedos_expected_commit=$FDOS_COMMIT"
    [[ -f "$DONOR_DIR/linux-0.01.tar.gz" ]] && echo "linux_actual_sha256=$(sha256sum "$DONOR_DIR/linux-0.01.tar.gz" | awk '{print $1}')"
    [[ -d "$DONOR_DIR/freedos-kernel/.git" ]] && echo "freedos_actual_commit=$(git -C "$DONOR_DIR/freedos-kernel" rev-parse HEAD 2>/dev/null || true)"
    echo "completion_marker=HOSTILE_OS_DONOR_LOCK_COMPLETE"
  } > "$RECEIPT"
  echo "RECEIPT=$RECEIPT"
  echo "LOG=$LOG"
  exit "$RC"
}
trap finish EXIT

echo "HOSTILE-OS DONOR LOCK"
echo "START=$START"
echo "ROOT=$ROOT"
echo "uname=$(uname -a)"
echo "git=$(git --version)"
echo "curl=$(curl --version | head -1)"
echo "sha256sum=$(sha256sum --version | head -1)"

# Linux 0.01 exact canonical archive
curl --fail --location --proto '=https' --tlsv1.2 \
  "$LINUX_URL" -o "$DONOR_DIR/linux-0.01.tar.gz.part"
printf '%s  %s\n' "$LINUX_SHA" "$DONOR_DIR/linux-0.01.tar.gz.part" | sha256sum -c -
mv "$DONOR_DIR/linux-0.01.tar.gz.part" "$DONOR_DIR/linux-0.01.tar.gz"
rm -rf "$DONOR_DIR/linux-0.01"
mkdir "$DONOR_DIR/linux-0.01"
tar -xzf "$DONOR_DIR/linux-0.01.tar.gz" -C "$DONOR_DIR/linux-0.01"
chmod -R a-w "$DONOR_DIR/linux-0.01"

# FreeDOS exact official repository commit
if [[ ! -d "$DONOR_DIR/freedos-kernel/.git" ]]; then
  git clone --filter=blob:none "$FDOS_REPO" "$DONOR_DIR/freedos-kernel"
fi
git -C "$DONOR_DIR/freedos-kernel" fetch --tags --force origin
git -C "$DONOR_DIR/freedos-kernel" checkout --detach "$FDOS_COMMIT"
test "$(git -C "$DONOR_DIR/freedos-kernel" rev-parse HEAD)" = "$FDOS_COMMIT"
git -C "$DONOR_DIR/freedos-kernel" status --porcelain=v1
# Record a deterministic source-tree object identity. Git tree is canonical for the repo snapshot.
echo "freedos_tree=$(git -C "$DONOR_DIR/freedos-kernel" rev-parse HEAD^{tree})"

# Do not chmod .git; worktree immutability is a policy boundary, source identity is Git object identity.
find "$DONOR_DIR/freedos-kernel" -path "$DONOR_DIR/freedos-kernel/.git" -prune -o -type f -exec chmod a-w {} +

echo 'DONOR LOCK QUALIFICATION COMPLETE'
