# Attention Reservoir - Foundation State

## SELECTED
**Donor qualification and responsibility-first forensic baseline.**

Open question: what responsibilities/invariants are actually present in Linux 0.01 and FreeDOS before inherited OS nouns bias the architecture?

## HIGH-VALUE DEFERRED
- Scheduler irreducibility vs composed arbitration.
- ECS-like identity/component/transform model vs conventional object taxonomy vs hybrid.
- Memory/address-space isolation as primitive vs composed capability phenotype.
- Persistent data semantics without prematurely importing `filesystem` ontology.
- Device control: direct substrate capability vs driver civilization.
- Fault/restart requalification and no-mature-state-injection.
- Compatibility architecture and whether compatibility belongs in core or boundary holons/adapters.
- Multicore evolution from originally single/limited donor assumptions.
- Security/authority primitive shape.
- Event/history/journal retention economics.
- Offline-generated target specialization vs adaptive runtime paths.

## SEALED UNTIL EARNED
- Windows NT architecture comparisons.
- Modern Linux design as solution donor.
- BSD/Plan9/microkernel/capability-OS solution mining.
- Reopening KarnOS/Holonix design docs for architecture selection beyond the already recorded contamination ledger.

## CROSS-PROJECT QUARRY READY
- FtD: capability-derived role, recomposition, native substrate orchestration.
- Aedifex: governance/expression/phenotype/lifetime/substrate separation.
- Microseed: composition-first capability growth and authority gating.
- PAL/TRCH: evidence/currentness/UNKNOWN/query-relative use.
- CIC: exact current authority, requalification, runtime/source separation.
- Forge/HSP/CSC: research/assurance machinery.
- Ergo/VoidStar: offline leverage, locality, resource asymmetry, scars.
- Rust ECS/CogOS: physical-floor and whole-envelope pressure.
- CFE: ontology leakage/coverage/causal-depth tests.

## REOPEN CONDITIONS
Any sealed branch may reopen when:
1. current donors cannot discriminate a live question;
2. a safety/security/compatibility claim would otherwise exceed evidence;
3. a candidate stabilizes and external convergence checking is now valuable;
4. new external hardware reality makes the current donor space unrepresentative.
