# HOSTILE-OS Reincarnation Bootloader - Foundation F0

**Date:** 2026-08-26  
**Status:** FOUNDING AUTHORITY; NO OS PASS YET PROMOTED  
**Working project name:** HOSTILE-OS  
**Campaign motto:** `FREE-DOS + LINUX -> FUCK WINDOWS, AGAIN.`

This is a reincarnation bootloader, not a summary. Read it before proposing architecture.

## Commander's Intent

Re-derive a general-purpose operating substrate from real responsibilities/invariants using Linux 0.01 and FreeDOS as competing donors, while scavenging every prior project for mechanisms/scars/process law without granting any donor architectural authority.

The supreme constraint is **Pareto-optimal size/power subject to required capability**. No mechanism is larger than it needs to be; extra burden is admitted only when it buys genuine capability/guarantee. The frontier is multidimensional and may not be collapsed into one global scalar.

## Current authority order

```text
exact donor bytes/hashes + exact current source/log/runtime evidence
> this package's explicit ledgers
> current project files/qualified experiment artifacts
> older sealed project artifacts
> donor research/ancestral project documents
> conversation recollection
> model inference
```

Later timestamp alone does not trump exact authority.

## Primary donors

- Linux 0.01: kernel.org historical `linux-0.01.tar.gz`; SHA-256 `24454f830cdb571e2c4ad15481119c43b3cafd48dd869a9b2945d1036d1dc68d`.
- FreeDOS kernel: official `FDOS/kernel`; tag `ke2046`; commit `5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3`.

Bytes are identified but not materialized inside the current ChatGPT container. No source-level pass has been counted.

## Governing laws

1. Steal mechanisms/invariants/scars, not architectures/dogma.
2. Composition first. Missing behavior does not imply missing primitive.
3. Emergent capability is allowed; emergent authority is not.
4. Actual consequence outranks intended consequence.
5. UNKNOWN and negative evidence are durable.
6. Currentness must be re-earned after restart/change; history does not grant current authority.
7. Runtime adaptation cannot silently rewrite governing law.
8. Evidence inherits; confidence does not.
9. Same shape across donors/projects earns a discriminator, not merged identity.
10. Every abstraction pays rent on the Pareto frontier.
11. HSP/Loop+/OARR/PDVER/Helix/Attention Reservoir remain distinct roles.
12. CSC/Genome is audit-only by default; checker must earn right to check.
13. Scientific launches are durable and post-inspected before evidence counts.
14. No silent reintroduction of rejected/ancestral mechanisms.
15. Exact code/source lineage must be inspected before implementation.

## Critical contamination

The user previously designed Holonic OS/Holonix and KarnOS; FtD and Microseed also contain capability/ECS/holonic composition. KarnOS explicitly proposed schedulerless stigmergy. Therefore:

- ECS-like OS is a live hypothesis, not a clean-room personal discovery.
- no-scheduler/composed-arbitration is a live hypothesis, not a clean-room personal discovery.
- future convergence may be called re-derived/supported, not independent of internal ancestry.

## Current selected question

> What externally observable responsibilities and invariants are actually carried by Linux 0.01 and FreeDOS during the smallest useful boot/execution workloads, without granting inherited subsystem nouns primitive status?

## Next lawful operation

Run the durable donor-lock launcher on the development machine. Verify hashes/commit, unpack read-only donor trees, record toolchain/environment, inspect logs and exit receipts. Only then begin Campaign 001 Pass 1.

## Campaign cadence

20-pass bounded slices. Pass N+1 answers the discriminator exposed by Pass N. Attention Reservoir breadth check after every pass. Stop/reconcile after Pass 20.

## Read next

1. `01_CONTINUOUS_FORENSIC_HISTORY.md`
2. `02_CONSTITUTION_AND_LAWS.md`
3. `03_CROSS_PROJECT_QUARRY_LEDGER.md`
4. `04_DONOR_LOCK_AND_CONTAMINATION_LEDGER.md`
5. `05_CAMPAIGN_000_PREREGISTRATION.md`
6. `08_NEVER_SILENTLY_REINTRODUCE.md`
7. `CONTINUITY_STATE.json`
