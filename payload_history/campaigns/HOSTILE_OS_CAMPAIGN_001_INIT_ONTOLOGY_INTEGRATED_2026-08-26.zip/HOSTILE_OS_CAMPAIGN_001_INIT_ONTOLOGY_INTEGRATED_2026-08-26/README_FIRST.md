# HOSTILE-OS — CAMPAIGN 001 INITIALIZATION

**Local project date:** 2026-08-26 (America/New_York)  
**State:** Campaign 001 initialized; scientific passes earned = 0.  
**Sealed ancestry:** `HOSTILE_OS_GENESIS_2026-08-26.zip` (hash in `F0_ANCESTRY_SHA256.txt`).

This continuation does **not mutate Foundation F0**. It records initialization evidence, infrastructure scars, the first workload fixture, and the exact gate that remains before C001/P01 may count.

## Current gate

P01 remains blocked until:
1. canonical `linux-0.01.tar.gz` is locally materialized and SHA-256 verifies as `24454f830cdb571e2c4ad15481119c43b3cafd48dd869a9b2945d1036d1dc68d`;
2. FreeDOS source is locally materialized at exact commit `5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3`;
3. local source trees are frozen read-only;
4. runnable/build constraints are durably recorded;
5. baseline boot/use evidence is collected where runnable.

## Initialization evidence already earned

- Durable donor-fetch attempt executed and failed with DNS resolution error; receipt inspected. This is infrastructure evidence, not donor evidence.
- Durable toolchain/emulator census executed successfully; receipt inspected.
- Remote canonical/official source surfaces were used only for **shadow reconnaissance**. Those clues cannot promote a mechanism or count as P01.

## First live scientific question after the gate

> What externally observable responsibilities and invariants are carried by Linux 0.01 and FreeDOS under minimal boot/use without granting subsystem nouns primitive status?

## Artifact scars earned during initialization

- **I-001:** canonical fetch can be blocked by runtime network/DNS; offline exact import is mandatory rather than weaker provenance.
- **I-002:** executable artifacts require explicit interpreter provenance and an execution preflight; syntax-valid source alone does not prove runnable tooling.

## Ontology quarry addendum
Before P01 execution, the prior ontology research corpus was mined for process laws and scars. It does not promote a runtime ontology. See `research/ONTOLOGY_SCAVENGE_V0_1.md`, the P01 ontology-lens preregistration addendum, and non-promotional donor collision reconnaissance. Scientific passes remain 0.

- **I-003:** final closure verification must be non-mutating. Verification receipts for a sealed package live outside the payload; otherwise verification itself changes the artifact being attested.
