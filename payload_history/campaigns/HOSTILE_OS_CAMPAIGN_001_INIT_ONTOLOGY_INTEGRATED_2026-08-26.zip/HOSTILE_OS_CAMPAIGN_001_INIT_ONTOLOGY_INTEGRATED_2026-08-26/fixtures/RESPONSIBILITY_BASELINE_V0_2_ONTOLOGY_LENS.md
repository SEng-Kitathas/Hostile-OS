# Responsibility Baseline Fixture v0.2 — Ontology Lens

This extends v0.1 without replacing it. Workload situations are unchanged; recording is richer.

For each R01–R10 situation in `RESPONSIBILITY_BASELINE_V0_1.md`, capture:

| Plane | Question |
|---|---|
| identity | what referent persists across the transition, if any? |
| applicability | does this operation/state distinction apply here? |
| current capability | what can the referent actually do now? |
| authority | who/what may cause the transition? |
| eligibility | what currently makes progress lawful/possible? |
| resource | what scarce thing is claimed/released? |
| wait relation | what condition prevents progress? |
| wake relation | what changed to permit progress? |
| world event | what happened externally/in hardware? |
| observation | what did donor software observe? |
| record | what historical state is retained? |
| accepted transition | what internal state changed? |
| failure | how is bounded failure represented? |
| unknown | what distinction cannot yet be resolved? |

### Compression probe
After observation, ask whether any two recorded distinctions can be merged without changing any reachable future relevant to the fixture. Do not merge during P01; record candidates only.

### Split probe
If one donor field/value/name produces materially different consequences in different contexts, record the context discriminator rather than forcing one universal meaning.
