# Responsibility Baseline Fixture v0.1

Purpose: create the smallest causal workload that can expose what the donors actually have to do.

The fixture is intentionally noun-hostile. It asks for outcomes, not conventional OS objects.

| ID | Required situation | Observable success/failure |
|---|---|---|
| R01 | machine begins from reset/boot medium | reaches first donor-defined usable execution state |
| R02 | one finite activity is requested | activity begins, advances, and returns or terminates |
| R03 | more than one progress-capable activity exists | donor exposes how compute ownership changes, or explicitly cannot |
| R04 | current activity cannot progress until condition X | useful compute is not accidentally consumed forever; continuation state remains recoverable |
| R05 | condition X becomes true | prior continuation may lawfully resume |
| R06 | named persistent bytes are requested | bytes are found/read or bounded failure is exposed |
| R07 | persistent bytes are changed | later read exposes donor-defined persistence semantics |
| R08 | no useful activity is available | donor enters a bounded idle behavior |
| R09 | asynchronous device/timer/input event occurs | event changes only state it is authorized/defined to affect |
| R10 | requested resource/program is absent or malformed | failure is bounded and observable; donor behavior is recorded exactly |

Do not normalize away donor differences. A missing responsibility is evidence about donor scope, not a test failure unless that donor claims it.
