#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys

root = Path(__file__).resolve().parents[1]
sha_path = root / "SHA256SUMS"
manifest_path = root / "MANIFEST.json"
errs = []

# SHA256SUMS covers every regular package file except itself.
entries = {}
for line in sha_path.read_text().splitlines():
    if not line.strip():
        continue
    expected, rel = line.split("  ", 1)
    if rel in entries:
        errs.append(f"DUPLICATE_SHA_ENTRY {rel}")
    entries[rel] = expected

actual_files = {
    p.relative_to(root).as_posix()
    for p in root.rglob("*")
    if p.is_file() and p != sha_path
}
sha_files = set(entries)
for rel in sorted(actual_files - sha_files):
    errs.append(f"UNHASHED {rel}")
for rel in sorted(sha_files - actual_files):
    errs.append(f"SHA_ENTRY_WITHOUT_FILE {rel}")
for rel, expected in entries.items():
    p = root / rel
    if not p.is_file():
        continue
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    if actual != expected:
        errs.append(f"HASH {rel} expected={expected} actual={actual}")

# MANIFEST covers payload files, excluding only the two closure metadata files.
manifest = json.loads(manifest_path.read_text())
rows = manifest.get("files", [])
manifest_entries = {row["path"]: row for row in rows}
manifest_expected = actual_files - {"MANIFEST.json"}
manifest_files = set(manifest_entries)
for rel in sorted(manifest_expected - manifest_files):
    errs.append(f"UNMANIFESTED {rel}")
for rel in sorted(manifest_files - manifest_expected):
    errs.append(f"MANIFEST_ENTRY_WITHOUT_FILE {rel}")
for rel, row in manifest_entries.items():
    p = root / rel
    if not p.is_file():
        continue
    b = p.read_bytes()
    actual_hash = hashlib.sha256(b).hexdigest()
    if row.get("bytes") != len(b):
        errs.append(f"MANIFEST_BYTES {rel} expected={row.get('bytes')} actual={len(b)}")
    if row.get("sha256") != actual_hash:
        errs.append(f"MANIFEST_HASH {rel} expected={row.get('sha256')} actual={actual_hash}")

if errs:
    print("\n".join(errs))
    sys.exit(1)
print(f"HOSTILE_OS_C001_INIT_PACKAGE_VERIFY_OK files={len(actual_files)}")
