#!/usr/bin/env bash
set -Eeuo pipefail

# Offline-capable exact donor import.
# Usage:
#   tools/import_and_lock_donors.sh <linux-0.01.tar.gz> <freedos-git-worktree>
# The FreeDOS path must be a git checkout containing exact commit 5ffb... as HEAD.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LINUX_IN="${1:?path to canonical linux-0.01.tar.gz required}"
FDOS_IN="${2:?path to FreeDOS git worktree required}"
LINUX_SHA='24454f830cdb571e2c4ad15481119c43b3cafd48dd869a9b2945d1036d1dc68d'
FDOS_COMMIT='5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3'
DONOR_DIR="$ROOT/donors"
mkdir -p "$DONOR_DIR"

[[ -f "$LINUX_IN" ]] || { echo "missing Linux archive: $LINUX_IN" >&2; exit 10; }
[[ -d "$FDOS_IN/.git" ]] || { echo "FreeDOS input must be a git worktree" >&2; exit 11; }

ACTUAL_LINUX="$(sha256sum "$LINUX_IN" | awk '{print $1}')"
[[ "$ACTUAL_LINUX" == "$LINUX_SHA" ]] || {
  echo "Linux SHA mismatch expected=$LINUX_SHA actual=$ACTUAL_LINUX" >&2; exit 12;
}
ACTUAL_FDOS="$(git -C "$FDOS_IN" rev-parse HEAD)"
[[ "$ACTUAL_FDOS" == "$FDOS_COMMIT" ]] || {
  echo "FreeDOS commit mismatch expected=$FDOS_COMMIT actual=$ACTUAL_FDOS" >&2; exit 13;
}
[[ -z "$(git -C "$FDOS_IN" status --porcelain=v1)" ]] || {
  echo "FreeDOS worktree is dirty; refusing import" >&2; exit 14;
}

rm -rf "$DONOR_DIR/linux-0.01" "$DONOR_DIR/freedos-kernel"
cp "$LINUX_IN" "$DONOR_DIR/linux-0.01.tar.gz"
mkdir "$DONOR_DIR/linux-0.01"
tar -xzf "$DONOR_DIR/linux-0.01.tar.gz" -C "$DONOR_DIR/linux-0.01"
git clone --no-hardlinks "$FDOS_IN" "$DONOR_DIR/freedos-kernel" >/dev/null
GIT_TERMINAL_PROMPT=0 git -C "$DONOR_DIR/freedos-kernel" checkout --detach "$FDOS_COMMIT" >/dev/null
[[ -z "$(git -C "$DONOR_DIR/freedos-kernel" status --porcelain=v1)" ]]

find "$DONOR_DIR/linux-0.01" -type f -exec chmod a-w {} +
find "$DONOR_DIR/freedos-kernel" -path "$DONOR_DIR/freedos-kernel/.git" -prune -o -type f -exec chmod a-w {} +

{
  echo "linux_sha256=$ACTUAL_LINUX"
  echo "freedos_commit=$ACTUAL_FDOS"
  echo "freedos_tree=$(git -C "$DONOR_DIR/freedos-kernel" rev-parse HEAD^{tree})"
  echo "linux_files=$(find "$DONOR_DIR/linux-0.01" -type f | wc -l)"
  echo "freedos_files=$(find "$DONOR_DIR/freedos-kernel" -path '*/.git/*' -prune -o -type f -print | wc -l)"
} | tee "$ROOT/evidence/init/donor_import_lock.txt"
