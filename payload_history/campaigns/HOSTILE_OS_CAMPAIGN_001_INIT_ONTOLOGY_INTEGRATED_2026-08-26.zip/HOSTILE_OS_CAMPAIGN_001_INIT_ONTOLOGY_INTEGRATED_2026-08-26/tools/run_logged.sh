#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAME="${1:?run name required}"; shift
test "${1:-}" = '--' || { echo 'expected -- before command' >&2; exit 2; }; shift
mkdir -p "$ROOT/logs"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$ROOT/logs/${NAME}_${STAMP}.log"
RECEIPT="$ROOT/logs/${NAME}_${STAMP}.receipt"
START="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
set +e
(
  set -o pipefail
  echo "run_name=$NAME"; echo "start_utc=$START"; echo "cwd=$(pwd)"; echo "command=$*"
  env | LC_ALL=C sort | sed 's/=.*$/=<redacted-or-value-present>/'
  echo '--- stdout+stderr ---'
  "$@"
) > >(tee "$LOG") 2>&1
RC=$?
set -e
END="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
{
  echo "run_name=$NAME"; echo "start_utc=$START"; echo "end_utc=$END"; echo "exit_code=$RC"
  echo "log_sha256=$(sha256sum "$LOG" | awk '{print $1}')"
  echo 'completion_marker=HOSTILE_OS_RUN_COMPLETE'
} > "$RECEIPT"
echo "exit_code=$RC"; echo "log=$LOG"; echo "receipt=$RECEIPT"
exit "$RC"
