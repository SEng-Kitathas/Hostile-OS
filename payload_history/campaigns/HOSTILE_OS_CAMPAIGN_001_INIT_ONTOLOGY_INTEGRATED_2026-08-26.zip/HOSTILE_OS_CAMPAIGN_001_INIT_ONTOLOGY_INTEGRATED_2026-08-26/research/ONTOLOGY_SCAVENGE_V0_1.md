# HOSTILE-OS Ontology Scavenge v0.1

**Status:** research/process donor integration; non-architectural.  
**Scientific pass authority:** NONE.  
**Purpose:** import scars, refinement laws, and discriminators from prior ontology work without importing a finished ontology or OS architecture.

## 1. Why ontology belongs in the hostile OS quarry

Ontology is not decoration. It determines what distinctions the system can represent, which distinctions are silently conflated, what can compose, what can be queried, what can be authorized, and what failure modes become invisible.

HOSTILE-OS therefore treats ontology itself as a Pareto surface. Every primitive noun, state enum, privilege category, lifetime class, and subsystem boundary incurs conceptual and assurance cost. A distinction earns permanent statehood only when removing it loses a behaviorally, causally, authority-, failure-, or future-relevant difference.

Conversely, a single label must split when it aliases cases with different reachable futures, authority, failure semantics, or composition behavior.

## 2. Recovered cross-project ontology scars

### OQ-001 — New label does not imply new mechanism
From TQ2/CIL ontology stability: external jargon must map to existing ontology before being admitted; an isomorph-predator pass is mandatory.

**OS translation:** `scheduler`, `process`, `thread`, `file`, `socket`, `driver`, `service`, `interrupt`, `task`, and `device` begin as donor labels, not HOSTILE-OS primitives.

### OQ-002 — Same label does not imply same concept
Semantic Quarry established `same label != same concept` and multiple collision firewalls across foreign ontologies.

**OS translation:** Linux `task`, FreeDOS `task`, a hardware task, and a future HOSTILE-OS execution-bearing composition cannot be equated by name.

### OQ-003 — Every semantic dimension gets one primary home
RuneFlow/CIC ontology work repeatedly found semantic overload when authority, permission, capability, state, evidence, provenance, topology, and identity bleed into one another.

**OS translation:** do not let a single field such as `state`, `flags`, `type`, `owner`, or `privilege` silently carry several independent meanings.

### OQ-004 — Identity != classification != capability != role
FtD/CIC/Aedifex refinement separated what something is called, what it can currently do, and what role it currently qualifies to perform.

**OS translation:** an identity may remain while current capability phenotype changes; role should derive from currently qualified capability rather than freeze capability from class membership.

### OQ-005 — Definition != claim != grant != permission != execution
CogTerm/CIC ontology work separated protocol features/grants from earned operational capability.

**OS translation:**
- operation exists in an interface;
- target currently supports it;
- caller is permitted to request it;
- resources currently permit it;
- operation actually executes successfully;
are separate facts.

### OQ-006 — Binding != applicability != commitment/result
TRCH killed the early collapse of binding, applicability, and commitment into one overloaded state.

**OS translation:** before a requested transformation executes, keep separate:
- what target was bound;
- whether the operation applies to that target/current state;
- whether authority permits it;
- whether required resources/conditions are currently satisfied;
- what consequence actually occurred.

A single errno/status code may report a surface outcome, but it must not become the internal ontology by accident.

### OQ-007 — Observation != evidence; evidence is claim-relative
CIC ontology work established that an observation only becomes evidence relative to a claim.

**OS translation:** a counter being nonzero, an interrupt firing, a queue being nonempty, or a service reporting `active` does not by itself prove the higher-order claim we care about. Measurements and the claims they support remain distinct.

### OQ-008 — World event != observation != record != transition
EPCIS/semantic-quarry work separated world events, observations, records, state-transition assertions, and operational dispositions.

**OS translation:**
- hardware condition/event;
- CPU/controller notification;
- OS observation/record;
- accepted state transition;
- resulting operational capability
must not be silently collapsed into `event happened`.

### OQ-009 — Historical record != current truth/currentness
CIL, Semantic Quarry, PAL, and Microseed preserve contradiction/supersession without rewriting history.

**OS translation:** a resource, route, capability, mapping, or authority can become stale/revoked/invalid while its historical occurrence remains true. Current state and lineage are separate planes.

### OQ-010 — Resource identity/ownership != operation/assertion authority
Semantic Quarry's `RESOURCE AUTHORITY != ASSERTION AUTHORITY` is a general anti-namespace scar.

**OS translation:** knowing who/what owns, names, created, or exposes a resource does not automatically establish who may mutate it, who may speak authoritatively about its state, or which transformation is permitted.

### OQ-011 — Topology != factual state != authority
CIC ancestry separated factual state from topology and tied topology to failure-domain reasoning. Plurality does not imply independence.

**OS translation:** dependency/attachment/communication graphs are first-class useful relations, but an edge does not itself confer permission, truth, health, or independence.

### OQ-012 — Unknown has kinds and causes
TRCH/Microseed separated unresolved binding, inapplicability, stale evidence, action-limited uncertainty, structurally non-identifiable uncertainty, and collection gaps.

**OS translation:** `not observed`, `not present`, `not supported`, `not currently reachable`, `not currently authorized`, and `not yet discovered` must not collapse into one absence bit.

### OQ-013 — Constitution != expression != phenotype != lifetime != environment
Aedifex's five-layer causal separation was later generalized into governance, active expression/configuration, runtime phenotype, learned/history state, and reality substrate.

**OS translation:** an adaptive OS must not let runtime learning silently rewrite constitutional authority or architecture. Hardware reality remains authoritative for external consequence.

### OQ-014 — State distinctions must earn future relevance
TRCH's predictive-state refinement: a latent distinction earns statehood when it preserves a difference that matters to reachable futures; states should split when future-relevant differences appear and merge when they do not.

**OS translation:** prefer the coarsest state representation that preserves differences relevant to execution, authority, recovery, failure, timing, resource use, and future composition. Merge/split must remain reopenable when new hardware/actions reveal a hidden difference.

### OQ-015 — A complete universal ontology is not a requirement
NEAL's complete-lattice meta-ontology is useful as a donor for generalization/specialization/context projection, but the universal completeness requirement remains quarantined.

**OS translation:** do not build a metaphysical type cathedral before the machine forces distinctions into existence.

## 3. Pareto integration

Ontology cost joins the non-scalar Pareto vector:

- primitive concepts;
- independent state dimensions;
- semantic coupling between dimensions;
- special cases/exceptions;
- invalid/inapplicable fields carried per entity;
- conversion/mapping burden;
- authority ambiguity;
- stale-state risk;
- assurance/test surface.

A larger ontology is lawful only when the added distinctions purchase genuine capability, correctness, safety, recovery, performance, interoperability, or compression of otherwise duplicated mechanisms.

## 4. HOSTILE-OS semantic admission rule

A candidate primitive distinction is admitted only if at least one hostile discriminator demonstrates that collapsing it with an existing distinction loses a future-relevant difference.

A candidate merge is lawful only if hostile tests show the merged representation preserves all currently relevant future behavior and does not erase scars required for later reopening.

This is intentionally analogous to Microseed capability admission: proposal is cheap; admission is earned.

## 5. Contamination warning

Prior ontology research is ancestry-contaminating evidence. These laws may shape questions and prevent known mistakes, but they may not be cited as proof that HOSTILE-OS needs any specific runtime object, ECS component family, scheduler replacement, capability system, graph store, or semantic kernel.
