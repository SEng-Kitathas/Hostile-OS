# C001 / P01 — Responsibility Inventory

**Status:** PREREGISTERED / NOT RUN.

## Question
What externally observable responsibilities and invariants are carried by Linux 0.01 and FreeDOS during boot and the smallest useful execution workload, expressed without granting historical subsystem nouns primitive status?

## Required workload classes
A donor need not implement every class. Absence is data.

1. enter a usable post-boot execution state;
2. run one finite user program/activity;
3. run or represent a second activity where donor semantics permit it;
4. block/wait for external progress or input;
5. resume after the waited-for condition;
6. perform persistent byte read/write where donor semantics permit it;
7. create/terminate/return from a subordinate execution context where available;
8. become idle with no useful work;
9. receive at least one asynchronous event/interrupt path;
10. encounter one bounded failure (missing executable, invalid access, absent resource, or donor-equivalent).

## Observation vocabulary
Use responsibility language first:
- execution eligibility;
- current execution ownership;
- scarce compute arbitration;
- wait condition representation;
- wake/resume transition;
- asynchronous consequence handling;
- address/state protection;
- persistent naming/byte retention;
- device transfer;
- parent/child continuation;
- error/failure containment;
- idle/resource relinquishment.

Historical nouns may be recorded in a separate implementation column only after the responsibility is stated.

## Output
For each donor: responsibility -> observable trigger -> state required -> consequence -> invariant -> implementation carrier -> scar/assumption -> UNKNOWN.

## Hard prohibition
No mechanism promotion, ECS mapping, scheduler deletion, subsystem naming, or architectural synthesis in P01. P01 is inventory only.
