# C001 / P01 Preregistration Addendum — Ontology Lens

**Status:** added before P01 execution. Original preregistration remains immutable and authoritative; this addendum narrows observation discipline without changing P01's question or promotion ceiling.

## Additional recording planes
For every observed donor responsibility, record independently where applicable:

1. **identity** — what continuing referent is being tracked?
2. **binding** — what concrete target/state did the operation refer to?
3. **applicability** — was the operation meaningful for that target/current state?
4. **capability** — could the target currently support the requested transformation?
5. **authority** — was the requester/transform permitted?
6. **eligibility/currentness** — were prerequisite relations currently valid?
7. **resource claim** — what scarce physical/logical resources were required?
8. **state transition** — what accepted internal change occurred?
9. **external consequence** — what actually happened in the substrate/world?
10. **history/provenance** — what past fact remains true after current state changes?
11. **UNKNOWN reason** — absent, unobserved, inapplicable, unsupported, stale, unbound, action-limited, or structurally ambiguous?

## Split/merge probe
For every donor field/class/state distinction encountered:

> If this distinction were removed, can any reachable future under P01's workload change in behavior, authority, failure, recovery, resource use, timing, or composition?

- If YES: candidate distinction earns further testing.
- If NO under current scope: candidate merge/compression goes to the Reservoir, not immediate mutation.
- If UNKNOWN: preserve distinction provisionally and record the missing discriminator.

## Noun firewall
Historical nouns may be listed only after the responsibility/state distinction is described. Same spelling across donors does not license equivalence.

## Explicit non-goals
P01 still may not:
- declare ECS the runtime representation;
- delete or replace a scheduler;
- invent a capability security architecture;
- promote a universal ontology;
- infer architecture from prior projects.
