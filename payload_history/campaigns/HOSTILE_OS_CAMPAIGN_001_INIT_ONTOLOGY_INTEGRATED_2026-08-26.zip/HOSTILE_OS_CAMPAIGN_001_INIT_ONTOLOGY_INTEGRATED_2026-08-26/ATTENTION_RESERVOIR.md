# Attention Reservoir — C001 Initialization

## SELECTED
Exact local donor import/qualification, then responsibility-first P01.

## IMMEDIATELY EXPOSED BUT DEFERRED UNTIL P01 EARNS IT
- Does `scheduler` decompose into eligibility + wait/wake + accounting + selection + budget expiry + idle?
- Does FreeDOS's lack of a Unix-like scheduler represent missing capability, a different execution contract, or responsibility distributed into execution/idle/interrupt mechanisms?
- Is `task/process` itself one object or a compatibility-shaped bundle?

## HIGH-VALUE DEFERRED
ECS/hybrid representation; capability authority; persistence ontology; device binding; multicore; security/isolation; restart/requalification; compatibility placement; event/journal economics; energy-aware arbitration.

## SEALED
Modern Linux/NT/BSD/Plan 9/microkernel solution mining; KarnOS/Holonix architecture reopening beyond contamination records.

## ONTOLOGY QUARRY — ADDED BEFORE P01
- Can execution-state distinctions be minimized by predictive/future equivalence rather than inherited process taxonomy?
- Does idleness need identity, or only interruptible resource relinquishment?
- Which Linux `task_struct` fields are invariant-coupled versus copied-by-convenience?
- Which FreeDOS PSP/PCB/environment/file relations form true capability bundles versus compatibility contracts?
- What UNKNOWN causes must remain distinct in discovery, capability, authority, and reachability?
- Can ontology/component count itself be tracked as a Pareto cost without creating a scalar objective?
- Does the donor convergence around per-access cursor/binding versus underlying resource justify a general `access relation` primitive, or does that collapse under mmap, random access, message endpoints, or devices?
- Is the shared read/write surface a deep invariant, a compatibility convenience, or an early form of capability-polymorphic operation?
