# Pre-Pass Shadow Reconnaissance — NON-PROMOTIONAL

**Authority ceiling:** orientation only. This file MUST NOT be cited as a scientific pass result.

## Linux 0.01 remote canonical history clues
The canonical historical v0.01 source describes minimal task switching, a single task structure, sleep/wakeup behavior, timer accounting, signal/alarm wakeups, and a schedule routine that selects runnable work by counters/priority. It also relies on the rule that kernel/fs/mm actions are effectively atomic when supervisor-mode code does not sleep.

### Shadow decomposition candidate
The source noun `scheduler` appears to carry multiple distinguishable responsibilities:
- mark/recognize runnable eligibility;
- transform alarms/signals into runnable state;
- choose among runnable claimants;
- account user/system CPU use;
- react to exhausted execution budget;
- represent sleeping/waiting continuations;
- wake waiting continuations;
- provide an idle fallback.

This is a clue, not a conclusion.

## FreeDOS exact-commit remote clues
At commit `5ffb5502d39a10a30f5b8a9e8beeba0bf30245d3`, `kernel/task.c` is primarily a DOS process loader/PSP/parent-child execution-state mechanism rather than a Unix-like run-queue scheduler. `kernel/dosidle.asm` can halt the CPU while idle and invokes DOS idle interrupt 28h when the DOS reentrancy state permits it.

### Shadow discriminator exposed
The same broad responsibility family (execution ownership / blocked work / idle / continuation) can be distributed very differently across donors. Therefore the first real comparison should not compare files named `sched.c` and `task.c`; it should compare the causal responsibilities they actually satisfy.
