# Pre-Pass Ontology Collision Reconnaissance

**Authority ceiling:** source-oriented shadow reconnaissance only. NOT C001/P01 evidence and NOT promotable architecture.

## Collision A — the donor noun `task` does not denote one common mechanism

### Linux 0.01
`struct task_struct` combines at least:
- current run state;
- compute budget/counter and priority;
- signals/handlers;
- exit state;
- execution identity and parent/group/session relations;
- credentials;
- alarms and CPU accounting;
- terminal/umask/filesystem roots/open files;
- address-space descriptors;
- hardware task-switch state.

The same source explicitly notes that task 0 is special and its `state` information is never used.

### FreeDOS
At the pinned FreeDOS commit, `pcb` is a very small task-switch carrier: SS, SP, and saved registers. Process embodiment is distributed through PSP/environment/file inheritance/load-transfer machinery in `task.c` and adjacent structures.

### Shadow scar
`TASK_LINUX != TASK_FREEDOS` despite lexical similarity.

The Linux record is a large cross-plane bundle; the FreeDOS PCB is closer to an execution continuation fragment. Therefore HOSTILE-OS must compare responsibilities and future-relevant state, not donor class names.

## Collision B — `schedule()` is a bundle of mechanisms

Linux 0.01 `schedule()` and its surrounding functions perform several separable jobs:
- temporal alarm consequence;
- signal-driven eligibility transition;
- runnable-state filtering;
- selection among claimants;
- execution-budget refresh;
- context switching;
- interruptible/uninterruptible wait representation;
- wake transition;
- timer accounting and budget expiration.

This does NOT prove a scheduler can be deleted. It establishes only that the historical noun encloses multiple candidate responsibility planes.

## Collision C — same operation label can have context-specific semantics

Linux 0.01 comments explicitly distinguish task 0 `pause()` from ordinary-task `pause()`: ordinary tasks require a signal to awaken, while task 0 uses pause as the idle loop's repeated opportunity to run other work.

Shadow implication: applicability/context may be a first-class qualifier; method name alone is not a sufficient semantic definition.

## Collision D — idleness has competing donor embodiments

Linux 0.01 embodies idleness as distinguished task 0 and selection fallback. FreeDOS has a direct idle path that may execute `HLT` and expose DOS idle interrupt 28h when its reentrancy state permits.

Preregistered future question:
> Does idle behavior require a persistent execution identity, or is identity merely one historical implementation of the physical requirement to relinquish/avoid useless compute while remaining interruptible?

No answer is promoted here.

## Collision E — creation by object-copy is not semantic proof

Linux 0.01 `copy_process()` copies the current `task_struct` wholesale, then resets/patches fields and increments inherited references. This is efficient historical implementation evidence, not proof that all copied dimensions form one irreducible process essence.

Preregistered future question:
> Which copied dimensions are truly coupled by invariant, which are inheritance policy, and which are historical convenience?

## Next lawful use

These collisions refine P01 observation vocabulary and later hostile discriminators. They do not alter the requirement for exact local donor qualification and baseline runtime evidence before P01 counts.

## Collision F — `file` decomposes across both donors

### Linux 0.01
Linux separates a per-open `struct file` (mode, flags, reference count, inode binding, current position) from the inode carrying object/device metadata and persistent/storage identity. The read/write syscall surface then dispatches by the bound inode's current kind/properties: pipe, character device, block device, directory, or regular file.

### FreeDOS
FreeDOS SFT entries likewise carry per-open/access state such as reference count, mode, current position, owner PSP, sharing data, and backing relation. The same transfer path can branch into remote access, character-device transfer, or block/file transfer. Character-device seek behavior is explicitly special rather than universally file-like.

### Shadow convergence candidate
Both donors independently suggest:

`FILE_LABEL != ONE_PRIMITIVE_OBJECT`

A useful decomposition candidate is:

`resource identity/backing + access binding + current operation capability/mode + per-access cursor + authority/ownership + transfer mechanism`

This is NOT promoted architecture. It is a future discriminator because both donors appear to separate at least some of these planes independently.

### Preregistered future question
> Which of these planes must remain distinct to preserve future behavior, and which can be composed generically enough that persistent bytes, pipes, devices, and remote resources become different capability bundles over shared access primitives?
