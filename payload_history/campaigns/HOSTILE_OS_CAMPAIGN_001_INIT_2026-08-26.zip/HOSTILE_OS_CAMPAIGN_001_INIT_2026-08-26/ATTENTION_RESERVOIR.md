# Attention Reservoir — C001 Initialization

## SELECTED
Exact local donor import/qualification, then responsibility-first P01.

## IMMEDIATELY EXPOSED BUT DEFERRED UNTIL P01 EARNS IT
- Does `scheduler` decompose into eligibility + wait/wake + accounting + selection + budget expiry + idle?
- Does FreeDOS's lack of a Unix-like scheduler represent missing capability, a different execution contract, or responsibility distributed into execution/idle/interrupt mechanisms?
- Is `task/process` itself one object or a compatibility-shaped bundle?

## HIGH-VALUE DEFERRED
ECS/hybrid representation; capability authority; persistence ontology; device binding; multicore; security/isolation; restart/requalification; compatibility placement; event/journal economics; energy-aware arbitration.

## SEALED
Modern Linux/NT/BSD/Plan 9/microkernel solution mining; KarnOS/Holonix architecture reopening beyond contamination records.
