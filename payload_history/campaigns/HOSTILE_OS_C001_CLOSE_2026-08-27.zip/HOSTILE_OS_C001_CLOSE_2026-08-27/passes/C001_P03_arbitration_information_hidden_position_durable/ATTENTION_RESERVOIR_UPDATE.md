# Reservoir after P03

- Tie rank vs identity: storage position currently supplies rank but is not identity.
- Counter/priority economics: algorithmic state cost and replenishment behavior need later pressure.
- Eligibility producer vs chooser: alarms/signals/wake are upstream of arbitration.
- Fallback slot0: idleness is a selected consequence, not absence of state.
- Table compaction/repacking would change equal-budget behavior unless tie rank is preserved separately.
- Multicore/coherency remains out of scope for this primordial single-CPU donor until later breadth sweep.
