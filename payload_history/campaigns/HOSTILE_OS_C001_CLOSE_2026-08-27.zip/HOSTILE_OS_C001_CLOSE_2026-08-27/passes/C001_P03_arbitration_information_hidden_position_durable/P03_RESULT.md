# C001 / P03 — Arbitration information and hidden position

**Disposition:** SURVIVED / NARROWED  
**Scientific pass:** 3

## Question

What information does Linux 0.01 compute arbitration actually require beyond (1) current eligibility, (2) per-activity budget/priority, and (3) an explicit tie/fallback rule; and is task-table position a future-relevant hidden input?

## Method

The exact selection loop in canonical `kernel/sched.c` was transcribed into a small executable reference model. A second model decomposed the same behavior into explicit phases:

1. form the currently eligible/runnable set;
2. if none exist, choose the fallback;
3. if any eligible activity has positive budget, choose the greatest budget;
4. resolve equal-budget ties with an explicit tie rank;
5. if all eligible budgets are zero, replenish counters from old counter + priority and repeat.

The decomposed model was exhaustively compared against the exact model over 2,197 three-slot task-state combinations. Existing tasks varied independently across runnable/not-runnable, counter 0..2, and priority 1..2. No donor source was changed.

## Result

**2,197 / 2,197 exact matches.** For this bounded state space, Linux's selection behavior can be represented without PID, parent relation, process group, session, open-file state, address-space state, or most of `task_struct`.

The selection phase needs only:

- presence/current candidate relation;
- runnable eligibility;
- current counter/budget;
- an explicit tie rank;
- a fallback identity.

Priority is not needed to choose among already-positive counters. It is needed only when all eligible counters are zero and budgets are replenished.

Alarm/signal/jiffies logic appears *before* the chooser and can change eligibility. P03 therefore keeps **eligibility production** separate from **arbitration among already-eligible activities**.

## Hidden input confirmed: task-table position

Canonical Linux scans task slots from high index toward low index and updates the winner only on strictly greater counter. Equal counters therefore preserve the first equal maximum encountered: **the higher task-table slot wins**.

The permutation probe used two otherwise symmetric runnable activities A and B with equal counter and priority:

- A in slot1, B in slot2 -> B wins;
- B in slot1, A in slot2 -> A wins.

Changing only storage position changes the selected logical activity. Table position is therefore a **future-relevant behavioral input** in Linux 0.01's exact arbitration, even though it is not named as scheduler state.

This is not identity. It is an implicit tie-ranking relation encoded by representation position.

## Split earned

P03 earns this semantic split:

`eligibility production -> eligible set -> budget/replenishment -> tie/fallback arbitration -> context switch`

That is a decomposition of responsibilities in the donor behavior. It is **not** a proposed OS architecture.

## Hostile findings

- **PID/lineage not required for current selection:** survived.
- **Priority required on every choice:** rejected; only the replenishment path needs it in this algorithm.
- **Task-table position irrelevant:** rejected. It changes equal-budget outcomes.
- **Tie policy is explicit in the source:** rejected. It is implicit in scan/storage order.
- **Fallback is “nothing happens”:** rejected. No eligible task chooses slot0, so fallback itself is a real consequence.

## Pareto note

An implementation that already stores activities in a stable ordered table can obtain deterministic tie behavior at zero extra metadata cost by reusing position. That is cheap. But it creates semantic coupling: moving/repacking entries can change execution order. Whether that coupling earns its keep is not answered here.

## P03 boundary

P03 does **not** establish that the scheduler is removable, that counters are optimal, that priority is necessary in HOSTILE-OS, or that Linux tie order should be preserved. It only exposes the exact information dependency of this donor mechanism and proves that storage position currently carries behavior.
