# C001 / P04 discriminator

**Question:** Does Linux 0.01's position-derived tie order buy any required capability under bounded competing-activity workloads, or is it accidental semantic coupling that can be replaced by an explicit lower-coupling tie relation without losing required behavior?

P04 must compare consequences under equal-budget contention. It may vary tie policy only in a model/experimental descendant; canonical donor behavior remains the reference, not something to silently “fix.”
