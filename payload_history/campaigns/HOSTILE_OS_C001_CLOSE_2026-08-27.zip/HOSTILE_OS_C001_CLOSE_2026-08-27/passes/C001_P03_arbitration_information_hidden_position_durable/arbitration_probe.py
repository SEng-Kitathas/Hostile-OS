#!/usr/bin/env python3
from itertools import product, permutations
from dataclasses import dataclass
import csv, json
from pathlib import Path
OUT=Path(__file__).resolve().parent
@dataclass(frozen=True)
class T:
    present: bool
    runnable: bool=False
    counter: int=0
    priority: int=1
    ident: str=''

def linux_exact(slots, max_rounds=32):
    # slots[0] is fallback task0; selection scans high slot -> 1.
    cur=list(slots)
    replenishments=0
    for _ in range(max_rounds):
        c=-1; nxt=0
        for i in range(len(cur)-1,0,-1):
            t=cur[i]
            if not t.present: continue
            if t.runnable and t.counter>c:
                c=t.counter; nxt=i
        if c != 0: # C truthiness: -1 and positive both break
            return nxt,replenishments,cur
        replenishments += 1
        cur=[t if not t.present else T(True,t.runnable,(t.counter>>1)+t.priority,t.priority,t.ident) for t in cur]
    raise RuntimeError('nontermination bound')

def decomposed(slots, max_rounds=32):
    cur=list(slots); replenishments=0
    for _ in range(max_rounds):
        eligible=[(i,t) for i,t in enumerate(cur[1:],1) if t.present and t.runnable]
        if not eligible:
            return 0,replenishments,cur
        maxc=max(t.counter for i,t in eligible)
        if maxc>0:
            # explicit tie rank reproduces hidden storage order: larger slot wins.
            winner=max((i for i,t in eligible if t.counter==maxc))
            return winner,replenishments,cur
        replenishments += 1
        cur=[t if not t.present else T(True,t.runnable,(t.counter>>1)+t.priority,t.priority,t.ident) for t in cur]
    raise RuntimeError('nontermination bound')

# Exhaustive 3 nonzero slots. Existing tasks: runnable/not; counter 0..2; priority 1..2.
states=[T(False)]
for run,c,p in product([False,True],range(3),[1,2]): states.append(T(True,run,c,p))
slot0=T(True,True,0,1,'idle0')
rows=[]; mismatch=[]; total=0
for combo in product(states, repeat=3):
    slots=[slot0,*combo]; total+=1
    a=linux_exact(slots); b=decomposed(slots)
    if (a[0],a[1]) != (b[0],b[1]): mismatch.append((combo,a,b))
    rows.append((a[0],a[1]))

# Explicit position-dependence probes with two logically symmetric tasks.
pos=[]
for assignment in [('A','B'),('B','A')]:
    slots=[slot0,T(True,True,5,1,assignment[0]),T(True,True,5,1,assignment[1]),T(False)]
    win,rep,_=linux_exact(slots)
    pos.append({'slot1':assignment[0],'slot2':assignment[1],'winner_slot':win,'winner_identity':slots[win].ident})

# Prove priority is irrelevant when a positive counter already selects a winner,
# but becomes relevant after all eligible counters reach zero.
priority_cases=[]
for pa,pb in product([1,2,7,15],[1,2,7,15]):
    slots=[slot0,T(True,True,3,pa,'A'),T(True,True,1,pb,'B'),T(False)]
    w,r,_=linux_exact(slots); priority_cases.append(('positive_counter',pa,pb,w,r))
    slots=[slot0,T(True,True,0,pa,'A'),T(True,True,0,pb,'B'),T(False)]
    w,r,_=linux_exact(slots); priority_cases.append(('zero_counter',pa,pb,w,r))

summary={
 'exhaustive_cases':total,
 'mismatches':len(mismatch),
 'decomposition_equivalent':not mismatch,
 'position_probes':pos,
 'required_current_selection_inputs':['present/eligible relation','runnable state','counter','explicit tie rank/fallback'],
 'replenishment_input':['priority'],
 'pre_arbitration_inputs_not_in_selection_phase':['alarm','signal','jiffies'],
 'lineage_inputs_not_used':['pid','father','pgrp','session'],
}
(OUT/'evidence'/'SIMULATION_SUMMARY.json').write_text(json.dumps(summary,indent=2))
with (OUT/'evidence'/'PRIORITY_PHASE_PROBE.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t'); w.writerow(['case','priority_A','priority_B','winner_slot','replenishments']); w.writerows(priority_cases)
if mismatch:
    (OUT/'evidence'/'MISMATCH.txt').write_text(repr(mismatch[:5])); raise SystemExit(1)
print(json.dumps(summary,indent=2))
