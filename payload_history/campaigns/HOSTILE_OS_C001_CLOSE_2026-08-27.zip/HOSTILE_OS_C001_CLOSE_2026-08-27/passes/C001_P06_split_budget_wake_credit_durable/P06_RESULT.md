# C001 / P06 — Split budget vs wake credit

**Disposition:** FAILED-TO-DOMINATE / NARROWED  
**Scientific pass:** 6

## Question
Can current service budget and recent non-use/wake credit be represented separately, preserving Linux 0.01's useful response/progress behavior with equal or lower total burden and without hidden starvation under wake pressure?

## Probe
A split policy kept ordinary q4 service budget separate from a one-bit wake credit. A credited activity receives one immediate service tick at the next arbitration. Two variants were attacked:

- unbounded credited selections;
- one credited selection followed by a forced normal q4 selection.

The matrix varied 1/3/8 CPU hogs, 1/2/4/8/16 recurrent sleepers, and sleep lengths 1/3/7.

## Result
The split is semantically possible but neither tested regulation rule dominates Linux's coupled counter behavior.

With 3 hogs + 1 fast sleeper, split credit matches/improves wake response with similar service and switch burden. Under many sleepers the hidden failure appears:

- **unbounded credit:** wake response becomes excellent, but the permanent hog receives only 4/10000 ticks with 8 or 16 sleepers; some sleepers also receive zero service because the credit queue itself can stay saturated;
- **cap-1 credit:** permanent hog progress is protected, but sleeper wake latency explodes (about 39 ticks with 8 sleepers, about 79 with 16 sleepers in the short-sleep case).

Linux's carry rule stays between those extremes: all tested activities progress, with bounded wake latency and no explicit fixed wake-vs-normal quota.

## Meaning
The useful information is not merely `woke_recently=true`. Under changing wake pressure the system needs some measure of **how much service an activity has or has not recently received**. A binary event flag loses magnitude/history and requires a second regulation rule; a fixed global cap then creates a new workload-sensitive knob.

This does not prove Linux's exact decay rule is minimal. It does reject the naive claim that `budget + wake bit` is an equal-capability lower-burden replacement.

## Claims
- Separate budget and wake state is impossible: **REJECTED.**
- One-bit wake credit is enough under hostile wake pressure: **REJECTED.**
- A fixed wake-credit quota is workload-agnostic: **REJECTED.**
- Linux's scalar is irreducible: **UNRESOLVED.**

## Next discriminator
Is the future-relevant state better described as bounded **service debt/credit** (recent service relative to eligibility/weight), and can such a relation reproduce Linux's adaptive response/fairness without importing a fixed wake quota?
