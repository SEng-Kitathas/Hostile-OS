#!/usr/bin/env python3
from dataclasses import dataclass,field
from collections import deque
import csv,json
@dataclass
class T:
 name:str; priority:int=4; counter:int=4; rank:int=0; kind:str='hog'; burst:int=1; sleep:int=1
 runnable:bool=True; service:int=0; cpu_burst:int=0; wake_at:int|None=None; wake_tick:int|None=None; lats:list=field(default_factory=list); credit:bool=False

class Linux:
 def pick(self,ts):
  while True:
   c=-1;n=None
   for x in sorted(ts,key=lambda z:z.rank,reverse=True):
    if x.runnable and x.counter>c:c=x.counter;n=x
   if c:return n
   for x in ts:x.counter=(x.counter>>1)+x.priority

class Split:
 def __init__(self,ts,q=4,cap=None):
  self.q=q;self.by={x.name:x for x in ts};self.norm=deque(x.name for x in ts if x.runnable);self.cred=deque();self.cur=None;self.left=0;self.cap=cap;self.credit_streak=0;self.credit_turn=False
 def wake(self,x):
  x.credit=True
  if x.name not in self.cred:self.cred.append(x.name)
  try:self.norm.remove(x.name)
  except ValueError:pass
 def block(self,x):
  if self.cur==x.name:self.cur=None;self.left=0
  for q in (self.norm,self.cred):
   try:q.remove(x.name)
   except ValueError:pass
  x.credit=False
 def _popr(self,q):
  for _ in range(len(q)):
   n=q.popleft();x=self.by[n]
   if x.runnable:return x
  return None
 def pick(self,ts):
  if self.cur is not None and self.left>0 and self.by[self.cur].runnable:return self.by[self.cur]
  if self.cur is not None:
   x=self.by[self.cur]
   if x.runnable and x.name not in self.norm and not x.credit:self.norm.append(x.name)
  self.cur=None
  force_norm=self.cap is not None and self.credit_streak>=self.cap
  x=None;credit=False
  if not force_norm:
   x=self._popr(self.cred);credit=x is not None
  if x is None:
   x=self._popr(self.norm);credit=False
  if x is None and force_norm:
   x=self._popr(self.cred);credit=x is not None
  if x is None:return None
  self.cur=x.name;self.credit_turn=credit
  if credit:
   x.credit=False;self.left=1;self.credit_streak+=1
  else:
   self.left=self.q;self.credit_streak=0
  return x
 def consume(self,x):
  self.left-=1
  if self.left==0:
   self.cur=None
   if x.runnable and not x.credit and x.name not in self.norm:self.norm.append(x.name)

def mk(hogs,sleepers,sleep=1):
 ts=[]
 for i in range(hogs):ts.append(T(f'H{i}',rank=i+1))
 for j in range(sleepers):ts.append(T(f'S{j}',rank=hogs+j+1,kind='sleeper',burst=1,sleep=sleep))
 return ts

def sim(policy,hogs,sleepers,sleep,ticks=10000):
 ts=mk(hogs,sleepers,sleep)
 pol=Linux() if policy=='linux' else Split(ts,4,None if policy=='split_unbounded' else 1)
 cur=None;switch=0;last=None
 for t in range(ticks):
  for x in ts:
   if not x.runnable and x.wake_at is not None and t>=x.wake_at:
    x.runnable=True;x.wake_at=None;x.wake_tick=t
    if isinstance(pol,Split):pol.wake(x)
  need=cur is None or not cur.runnable
  if isinstance(pol,Linux) and cur is not None and cur.counter<=0:need=True
  if isinstance(pol,Split) and cur is not None and pol.left<=0:need=True
  if need:
   cur=pol.pick(ts)
   if cur is None:continue
   if last!=cur.name:switch+=1
   last=cur.name
  cur.service+=1
  if cur.kind=='sleeper' and cur.wake_tick is not None:
   cur.lats.append(t-cur.wake_tick+1);cur.wake_tick=None
  if isinstance(pol,Linux):cur.counter-=1
  else:pol.consume(cur)
  if cur.kind=='sleeper':
   cur.cpu_burst+=1
   if cur.cpu_burst>=cur.burst:
    cur.cpu_burst=0;cur.runnable=False;cur.wake_at=t+1+cur.sleep
    if isinstance(pol,Split):pol.block(cur)
    cur=None
 hs=[x for x in ts if x.kind=='hog'];ss=[x for x in ts if x.kind=='sleeper'];l=[v for x in ss for v in x.lats]
 return {'policy':policy,'hogs':hogs,'sleepers':sleepers,'sleep':sleep,'ticks':ticks,'min_hog_service':min((x.service for x in hs),default=0),'hog_total':sum(x.service for x in hs),'sleeper_total':sum(x.service for x in ss),'min_sleeper_service':min((x.service for x in ss),default=0),'avg_wake_latency':round(sum(l)/len(l),3) if l else None,'max_wake_latency':max(l) if l else None,'switches':switch}
rows=[]
for h,s in [(3,1),(8,1),(1,2),(1,4),(1,8),(1,16)]:
 for sleep in [1,3,7]:
  for p in ['linux','split_unbounded','split_cap1']:
   rows.append(sim(p,h,s,sleep))
with open('evidence/MATRIX.tsv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t');w.writeheader();w.writerows(rows)
with open('evidence/SUMMARY.json','w') as f:json.dump(rows,f,indent=2)
for r in rows:
 if (r['hogs'],r['sleepers'],r['sleep']) in [(3,1,1),(1,8,1),(1,16,1)]:print(r)
