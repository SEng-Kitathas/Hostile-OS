# Attention Reservoir after P06
- Binary wake state lost service-history magnitude.
- Fixed wake quota created a workload-sensitive magic threshold.
- Test bounded service debt/credit before adding more state.
- Keep source-level question alive: Linux decay is an implicit bounded-credit law, not necessarily a primitive scheduler concept.
- Continue holding continuation/context, file-access binding/cursor, idle identity, and UNKNOWN-cause fronts.
