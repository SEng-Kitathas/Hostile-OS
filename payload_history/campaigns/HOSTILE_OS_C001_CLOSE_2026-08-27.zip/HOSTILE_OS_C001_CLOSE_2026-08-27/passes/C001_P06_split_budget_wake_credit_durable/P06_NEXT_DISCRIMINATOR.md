# C001 / P07 discriminator

Is the future-relevant state better described as bounded service debt/credit — recent service relative to eligibility/weight — and can such a relation reproduce Linux 0.01's adaptive response/fairness without a fixed wake quota?
