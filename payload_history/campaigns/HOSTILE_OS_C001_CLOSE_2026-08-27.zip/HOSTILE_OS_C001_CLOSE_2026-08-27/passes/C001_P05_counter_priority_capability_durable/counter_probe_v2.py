#!/usr/bin/env python3
from dataclasses import dataclass, field
from collections import deque
import csv,json

@dataclass
class Task:
    name:str; priority:int; counter:int; rank:int; kind:str='hog'; burst:int=1; sleep:int=1
    runnable:bool=True; service:int=0; cpu_in_burst:int=0; wake_at:int|None=None
    wake_tick:int|None=None; wake_latencies:list=field(default_factory=list)

class LinuxPolicy:
    def __init__(self,carry=True): self.carry=carry
    def pick(self,tasks):
        while True:
            c=-1;nxt=None
            # source scans high slot to low, strict >; rank models slot order
            for x in sorted(tasks,key=lambda q:q.rank,reverse=True):
                if x.runnable and x.counter>c:
                    c=x.counter;nxt=x
            if c:
                return nxt
            # exact source replenishes every existing task, including sleepers
            for x in tasks:
                x.counter=((x.counter>>1) if self.carry else 0)+x.priority

class RRPolicy:
    def __init__(self,tasks,q=4,wake_front=False,weighted=False):
        self.q=q;self.wake_front=wake_front;self.weighted=weighted
        self.queue=deque([x.name for x in tasks if x.runnable]);self.by={x.name:x for x in tasks}
        self.cur_name=None;self.left=0
    def on_wake(self,x):
        if x.name==self.cur_name or x.name in self.queue:return
        (self.queue.appendleft if self.wake_front else self.queue.append)(x.name)
    def on_block(self,x):
        if x.name==self.cur_name:self.cur_name=None;self.left=0
        try:self.queue.remove(x.name)
        except ValueError:pass
    def pick(self,tasks):
        if self.cur_name is not None:
            x=self.by[self.cur_name]
            if x.runnable and self.left>0:return x
            if x.runnable:self.queue.append(x.name)
            self.cur_name=None
        for _ in range(len(self.queue)):
            n=self.queue.popleft();x=self.by[n]
            if x.runnable:
                self.cur_name=n;self.left=self.q*(x.priority if self.weighted else 1);return x
            self.queue.append(n)
        return None
    def consume(self,x): self.left-=1

def fresh(n_hogs,period,prio_s=4,prio_h=4):
    ts=[Task(f'H{i}',prio_h,prio_h,i+1) for i in range(n_hogs)]
    burst,sleep=period
    ts.append(Task('S',prio_s,prio_s,0,kind='sleeper',burst=burst,sleep=sleep))
    return ts

def simulate(policy_name,n_hogs=3,period=(1,1),ticks=5000,prio_s=4,prio_h=4,q=4):
    tasks=fresh(n_hogs,period,prio_s,prio_h); sleeper=tasks[-1]
    if policy_name=='linux':pol=LinuxPolicy(True)
    elif policy_name=='linux_nocarry':pol=LinuxPolicy(False)
    else:pol=RRPolicy(tasks,q=q,wake_front=('wakefront' in policy_name),weighted=('weighted' in policy_name))
    current=None;switches=0;last=None;idle=0
    for t in range(ticks):
        # external wake events at tick boundary
        for x in tasks:
            if not x.runnable and x.wake_at is not None and t>=x.wake_at:
                x.runnable=True;x.wake_at=None;x.wake_tick=t
                if isinstance(pol,RRPolicy):pol.on_wake(x)
        # schedule only if no current/runnable current invalid/counter expired for Linux
        need = current is None or not current.runnable
        if isinstance(pol,LinuxPolicy) and current is not None and current.runnable and current.counter<=0: need=True
        if isinstance(pol,RRPolicy) and current is not None and pol.left<=0: need=True
        if need:
            current=pol.pick(tasks)
            if current is None:
                idle+=1;continue
            if last!=current.name:switches+=1
            last=current.name
        # one CPU tick of current
        current.service+=1
        if current.name=='S' and current.wake_tick is not None:
            current.wake_latencies.append(t-current.wake_tick+1);current.wake_tick=None
        if isinstance(pol,LinuxPolicy): current.counter-=1
        else: pol.consume(current)
        # workload may block after consuming burst
        if current.kind=='sleeper':
            current.cpu_in_burst+=1
            if current.cpu_in_burst>=current.burst:
                current.cpu_in_burst=0;current.runnable=False;current.wake_at=t+1+current.sleep
                if isinstance(pol,RRPolicy):pol.on_block(current)
                current=None
        # Linux timer preemption happens after tick if counter exhausted; represented next boundary
        # RR quantum likewise next boundary.
    h=[x for x in tasks if x.kind=='hog']
    return {'policy':policy_name,'hogs':n_hogs,'burst':period[0],'sleep':period[1],'ticks':ticks,
            'sleeper_service':sleeper.service,'hog_service_total':sum(x.service for x in h),
            'min_hog_service':min((x.service for x in h),default=0),
            'avg_wake_latency':round(sum(sleeper.wake_latencies)/len(sleeper.wake_latencies),4) if sleeper.wake_latencies else None,
            'max_wake_latency':max(sleeper.wake_latencies) if sleeper.wake_latencies else None,
            'switches':switches,'idle':idle}

def weighted_share(name):
    # no sleepers; compare long-run share
    tasks=[Task('A',1,1,1),Task('B',4,4,2)]
    pol=LinuxPolicy(True) if name=='linux' else RRPolicy(tasks,q=1,weighted=True)
    cur=None
    for t in range(5000):
        need=cur is None or (isinstance(pol,LinuxPolicy) and cur.counter<=0) or (isinstance(pol,RRPolicy) and pol.left<=0)
        if need:cur=pol.pick(tasks)
        cur.service+=1
        if isinstance(pol,LinuxPolicy):cur.counter-=1
        else:pol.consume(cur)
    tot=sum(x.service for x in tasks);return {x.name:x.service/tot for x in tasks}

# Hand trace from exact timer semantics: B gets its full counter before A due high-rank tie.
def validation():
    tasks=[Task('A',2,2,1),Task('B',2,2,2)];pol=LinuxPolicy(True);cur=None;out=[]
    for t in range(10):
        if cur is None or cur.counter<=0:cur=pol.pick(tasks)
        cur.service+=1;cur.counter-=1;out.append((cur.name,tasks[0].counter,tasks[1].counter))
    exp=[('B',2,1),('B',2,0),('A',1,0),('A',0,0),('B',2,1),('B',2,0),('A',1,0),('A',0,0),('B',2,1),('B',2,0)]
    return out,exp,out==exp

rows=[]
for hogs in [1,3,8]:
  for period in [(1,1),(1,3),(2,2),(1,7),(4,4)]:
    for pol in ['linux','linux_nocarry','rr_q4','rr_wakefront_q4','rr_q1']:
      rows.append(simulate(pol,hogs,period,5000,q=(1 if pol=='rr_q1' else 4)))
with open('evidence/MATRIX_v2.tsv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t');w.writeheader();w.writerows(rows)
out,exp,ok=validation()
summary={'exact_timer_trace_valid':ok,'trace':out,'expected':exp,
         'weighted_share_linux':weighted_share('linux'),'weighted_share_weighted_rr':weighted_share('weighted_rr')}
with open('evidence/SUMMARY_v2.json','w') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
for r in rows:
    if r['hogs'] in (3,8) and (r['burst'],r['sleep']) in ((1,1),(1,3)):
        print(r)
