# Attention Reservoir after P05

- Does non-use history need to persist while blocked, or can wake events derive an equivalent bounded credit?
- Does explicit separation of budget and response credit reduce hidden coupling enough to pay its state cost?
- Does wake-front behavior starve continuously runnable work as sleeper count rises?
- Can weighted service and response share one state relation without conflating two independent control goals?
- Keep P01 sibling fronts alive: continuation/context state, per-access cursor/binding vs backing, idle identity, UNKNOWN causes.
