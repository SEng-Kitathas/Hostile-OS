#!/usr/bin/env python3
from dataclasses import dataclass
from collections import deque
import json,csv

@dataclass
class Task:
    name:str; priority:int=4; counter:int=4; runnable:bool=True; rank:int=0
    service:int=0; wake_latencies:list=None; wake_tick:int|None=None
    def __post_init__(self):
        if self.wake_latencies is None: self.wake_latencies=[]

class Periodic:
    def __init__(self,run=1,sleep=1): self.run=run; self.sleep=sleep; self.phase=0
    def runnable(self,t): return (t%(self.run+self.sleep))<self.run

def linux_pick(tasks):
    # Exact semantic form of sched.c selection/replenishment excluding task0.
    while True:
        c=-1; nxt=None
        for x in sorted(tasks,key=lambda q:q.rank,reverse=True):
            if x.runnable and x.counter>c:
                c=x.counter; nxt=x
        if c: return nxt
        for x in tasks:
            x.counter=(x.counter>>1)+x.priority

def linux_tick(tasks):
    x=linux_pick(tasks); x.service+=1; x.counter=max(0,x.counter-1); return x

def linux_no_carry_pick(tasks):
    while True:
        c=-1;nxt=None
        for x in sorted(tasks,key=lambda q:q.rank,reverse=True):
            if x.runnable and x.counter>c:
                c=x.counter;nxt=x
        if c:return nxt
        for x in tasks: x.counter=x.priority

def linux_no_carry_tick(tasks):
    x=linux_no_carry_pick(tasks);x.service+=1;x.counter=max(0,x.counter-1);return x

class RR:
    def __init__(self,tasks,q=4,wake_front=False,weighted=False):
        self.q=q; self.wake_front=wake_front; self.weighted=weighted; self.queue=deque(); self.cur=None; self.left=0
        self.prev={x.name:x.runnable for x in tasks}; self.tasks={x.name:x for x in tasks}
        for x in tasks:
            if x.runnable:self.queue.append(x.name)
    def tick(self,tasks):
        # update wake edges
        for x in tasks:
            prev=self.prev.get(x.name,False)
            if x.runnable and not prev and x.name!=self.cur and x.name not in self.queue:
                (self.queue.appendleft if self.wake_front else self.queue.append)(x.name)
            if not x.runnable:
                if x.name==self.cur: self.cur=None;self.left=0
                try:self.queue.remove(x.name)
                except ValueError:pass
            self.prev[x.name]=x.runnable
        if self.cur is None or self.left<=0 or not self.tasks[self.cur].runnable:
            if self.cur is not None and self.tasks[self.cur].runnable and self.cur not in self.queue:self.queue.append(self.cur)
            # discard nonrunnable
            for _ in range(len(self.queue)):
                n=self.queue.popleft()
                if self.tasks[n].runnable: self.cur=n;break
                self.queue.append(n)
            else:self.cur=None
            if self.cur is not None:
                base=self.tasks[self.cur].priority if self.weighted else 1
                self.left=self.q*base
        if self.cur is None:return None
        x=self.tasks[self.cur];x.service+=1;self.left-=1
        if self.left==0:
            n=self.cur;self.cur=None
            if x.runnable:self.queue.append(n)
        return x

def run(policy_name,n_hogs=3,period=(1,1),ticks=2000,prio_s=4,prio_h=4,q=4):
    tasks=[Task(f'H{i}',prio_h,prio_h,True,i+1) for i in range(n_hogs)]
    s=Task('S',prio_s,prio_s,True,0);tasks.append(s); p=Periodic(*period)
    rr=None
    if policy_name.startswith('rr'):
        rr=RR(tasks,q=q,wake_front=('wakefront' in policy_name),weighted=('weighted' in policy_name))
    switches=0;prev=None
    for t in range(ticks):
        was=s.runnable; s.runnable=p.runnable(t)
        if s.runnable and not was:s.wake_tick=t
        for h in tasks[:-1]:h.runnable=True
        if policy_name=='linux':x=linux_tick(tasks)
        elif policy_name=='linux_nocarry':x=linux_no_carry_tick(tasks)
        else:x=rr.tick(tasks)
        if x is not None:
            if prev!=x.name:switches+=1
            prev=x.name
            if x.name=='S' and s.wake_tick is not None:
                s.wake_latencies.append(t-s.wake_tick+1);s.wake_tick=None
    return {'policy':policy_name,'hogs':n_hogs,'run':period[0],'sleep':period[1],'ticks':ticks,
            'sleeper_service':s.service,'hog_service_total':sum(x.service for x in tasks[:-1]),
            'min_hog_service':min(x.service for x in tasks[:-1]) if n_hogs else 0,
            'avg_wake_latency':sum(s.wake_latencies)/len(s.wake_latencies) if s.wake_latencies else None,
            'max_wake_latency':max(s.wake_latencies) if s.wake_latencies else None,'switches':switches}

def weighted_share(policy):
    tasks=[Task('A',1,1,True,1),Task('B',4,4,True,2)]
    rr=RR(tasks,q=1,weighted=(policy=='weighted_rr')) if policy!='linux' else None
    for _ in range(5000):
        (linux_tick(tasks) if policy=='linux' else rr.tick(tasks))
    tot=sum(x.service for x in tasks)
    return {x.name:x.service/tot for x in tasks}

# exact hand trace validation for 2 tasks, equal priority 2, ranks 1/2.
def exact_trace():
    ts=[Task('A',2,2,True,1),Task('B',2,2,True,2)]
    out=[]
    for _ in range(10):
        x=linux_tick(ts);out.append((x.name,ts[0].counter,ts[1].counter))
    expected=[('B',2,1),('A',1,1),('B',1,0),('A',0,0),('B',2,1),('A',1,1),('B',1,0),('A',0,0),('B',2,1),('A',1,1)]
    return out, expected, out==expected

rows=[]
for hogs in [1,3,8]:
  for period in [(1,1),(1,3),(2,2),(1,7)]:
    for pol in ['linux','linux_nocarry','rr_q4','rr_wakefront_q4','rr_q1']:
      q=1 if pol=='rr_q1' else 4
      rows.append(run(pol,hogs,period,5000,q=q))

with open('evidence/MATRIX.tsv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t');w.writeheader();w.writerows(rows)
trace,expected,valid=exact_trace()
summary={
 'exact_trace_valid':valid,'exact_trace':trace,'expected_trace':expected,
 'weighted_share_linux':weighted_share('linux'),'weighted_share_weighted_rr':weighted_share('weighted_rr'),
 'rows':rows
}
with open('evidence/SUMMARY.json','w') as f:json.dump(summary,f,indent=2)
print(json.dumps({'exact_trace_valid':valid,'weighted_share_linux':summary['weighted_share_linux'],'weighted_share_weighted_rr':summary['weighted_share_weighted_rr']},indent=2))
for r in rows:
    if r['hogs']==3 and (r['run'],r['sleep'])==(1,1):print(r)
