# P05 harness scar 001

The first probe version called the arbitration function every simulated tick. Linux 0.01 does not do that: `do_timer()` keeps the current user task until its counter expires, unless the task blocks/yields through another path. Wake-up only makes a task runnable; it does not preempt the current task immediately.

Therefore the first MATRIX/SUMMARY output is INVALID scientific evidence. It is retained only as a harness scar. P05 remains uncounted. `counter_probe_v2.py` replaces it with an execution-loop model matching the donor's timer/block semantics.
