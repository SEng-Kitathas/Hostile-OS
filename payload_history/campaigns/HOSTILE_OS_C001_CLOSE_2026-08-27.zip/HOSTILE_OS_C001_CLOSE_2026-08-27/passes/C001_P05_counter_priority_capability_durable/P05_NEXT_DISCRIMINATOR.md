# C001 / P06 discriminator

Can current service budget and recent non-use/wake credit be represented separately, preserving Linux 0.01's useful response/progress behavior with equal or lower total burden and without hidden starvation under wake pressure?

P06 must compare response, finite progress/starvation, switch rate, state burden, and behavior under multiple sleeper populations. It may not call split state "cleaner" unless the split buys a measured future-relevant distinction.
