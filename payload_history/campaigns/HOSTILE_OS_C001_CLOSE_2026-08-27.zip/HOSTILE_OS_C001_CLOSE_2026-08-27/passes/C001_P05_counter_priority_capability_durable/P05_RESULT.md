# C001 / P05 — Counter + priority capability

**Disposition:** NARROWED / SURVIVED-AS-CAPABILITY-BUNDLE  
**Scientific pass:** 5

## Question

What capability do Linux 0.01's per-task `counter` and priority/replenishment rules buy beyond bounded progress available from a simpler eligible-set + quantum/rotation policy?

## Execution scar before result

The first P05 simulator was wrong: it re-ran arbitration every simulated tick. Canonical Linux 0.01 instead lets the current user task continue until `do_timer()` exhausts its counter, unless another path blocks/yields. The invalid outputs are retained under `INVALID_*`; they are not evidence. `counter_probe_v2.py` models timer/block/wake semantics and its hand trace matches the exact donor rule.

## Result

The donor rule carries at least two separable capabilities:

1. **`priority` replenishment rate buys weighted long-run CPU service.** With continuously runnable priorities 1 and 4, both Linux's rule and a simple weighted rotation converge to 20/80 service. The weighting capability therefore does not require Linux's decaying carry rule.
2. **The carry term `counter >> 1` preserves recent non-use and improves wake response under contention without forcing arbitration every tick.** With 3 or 8 CPU hogs and short blocking bursts, removing only carry roughly doubles wake latency in several probes while leaving all hogs progressing.

The carry benefit is conditional. With one hog or long CPU bursts, carry can make no difference. A 1-tick rotation or wake-front rotation can beat Linux wake latency, but at higher switching cost and/or worse service to continuously runnable work.

## Exact-rule validation

The corrected model reproduces a hand-derived timer trace for two equal-priority tasks: the high-rank task consumes its full counter before the other task runs, then both are replenished when all runnable counters reach zero. Validation result: `exact_timer_trace_valid=true`.

## Hostile comparison

Across 1/3/8 hogs and five burst/sleep patterns:

- Linux carry: all hogs made progress; worst measured wake latency 31 ticks.
- no-carry Linux: all hogs made progress; worst measured wake latency 32 ticks, with materially worse response in short-burst/high-contention cases.
- RR q4: similar bounded progress and switch cost to no-carry; worse wake response than Linux carry in the high-contention short-burst cases.
- RR q1: strong wake response but roughly 3x arbitration/context-switch count on average in this matrix.
- wake-front RR q4: strongest wake response in the matrix, but reduced minimum hog service under high wake pressure; it changes the fairness contract.

No policy dominates across response, switch burden, and continuously-runnable service.

## Interpretation

Linux 0.01's `counter` is not merely "remaining quantum." Because sleeping tasks retain counter and all tasks receive decayed carry on replenishment, it also encodes **recent CPU-use history / unused service credit**. That history buys real behavior, so it cannot be stripped just because one scalar carries two meanings.

But the two meanings are not yet proven irreducible:

`counter = current service budget + recent non-use history`

and

`priority = replenishment weight`

are candidate independent planes.

## Claims

- "Counter is just a timeslice": **REJECTED.**
- "Priority requires Linux's carry rule": **REJECTED.**
- "Carry buys no behavior": **REJECTED.**
- "Linux rule dominates simple rotation": **REJECTED.**
- "One scalar must carry budget and history": **UNRESOLVED.**

## Next discriminator

Can current service budget and recent non-use/wake credit be represented separately, preserving Linux's useful response/progress behavior with equal or lower total burden and without hidden starvation under wake pressure?
