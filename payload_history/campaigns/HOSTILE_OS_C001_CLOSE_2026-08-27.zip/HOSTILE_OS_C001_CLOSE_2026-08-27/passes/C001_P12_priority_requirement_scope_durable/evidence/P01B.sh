read X < P01.DAT
echo L_R07_REBOOT_READ_OK $X
echo L_R04_WAIT2
read Y
echo L_R05_WAKE2_OK $Y
