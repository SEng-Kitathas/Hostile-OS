# C001 / P13 discriminator
Does the qualified P01 workload require graded non-use service credit/counter history, or does any starvation-free bounded arbitration among eligible activities preserve the P01 consequences?
