# C001 / P12 — Priority requirement scope

**Disposition:** NOT REQUIRED BY P01 / RETAIN AS DONOR CAPABILITY  
**Scientific pass:** 12

The qualified Linux P01 fixture does not invoke `nice`, assign heterogeneous weights, or require a weighted-service outcome. Its required observations are boot, finite execution, multiple progress-capable activities, block/wake, persistence, bounded failure, child return, and asynchronous/event consequences.

Linux children inherit task state through `copy_process`; P01 supplied no discriminator that changes replenishment weight. Therefore P01 does not distinguish Linux's weighted policy from an equal-weight bounded policy.

This is not evidence that priority is useless. P05/P11 showed real weighted-service capability. It is simply **extra capability relative to P01's minimum requirement**.

Minimality rule: do not promote a state dimension merely because a donor has it.

**Next:** with priority removed from the minimum P01 requirement, does P01 itself require Linux's graded non-use credit/counter history, or only some bounded lawful arbitration among eligible activities?
