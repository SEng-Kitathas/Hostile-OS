# Attention Reservoir after P12
- Weighted service is real but outside current P01 minimum.
- Separate donor capability inventory from primitive admission.
- Test whether graded credit is also extra under P01 before moving to continuation state.
