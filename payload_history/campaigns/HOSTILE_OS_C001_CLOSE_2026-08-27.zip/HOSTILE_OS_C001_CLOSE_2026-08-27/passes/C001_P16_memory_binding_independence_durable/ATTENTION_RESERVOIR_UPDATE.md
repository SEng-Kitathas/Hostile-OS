# Attention Reservoir after P16
- Raw register snapshot != memory interpretation binding.
- Physical co-restoration does not erase semantic independence.
- Next attack open-resource bindings; this connects execution phenotype to file/access quarry.
