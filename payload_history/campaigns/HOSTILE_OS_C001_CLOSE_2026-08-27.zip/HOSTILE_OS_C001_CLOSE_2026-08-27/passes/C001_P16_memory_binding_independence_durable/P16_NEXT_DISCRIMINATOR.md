# C001 / P17 discriminator
Is open-resource/access state part of the execution continuation invariant, or an independent binding that can change while continuation identity remains valid?
