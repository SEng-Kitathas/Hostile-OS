# C001 / P16 — Memory/address binding is independent

**Disposition:** SPLIT-SUPPORTED  
**Scientific pass:** 16

Both donors preserve address interpretation alongside register state, but by different mechanisms: Linux TSS/LDT/page context includes `cr3` and segment selectors; FreeDOS continuation includes segmented register context.

A direct counterexample shows why this distinction is future-relevant: identical instruction offsets and general registers under two different mapping bases fetch different bytes and therefore have different futures.

So raw continuation values and **the binding that gives those values meaning** cannot be collapsed in the general case.

Candidate relation set now contains at least:

`identity -> continuation` and `continuation/execution -> memory interpretation binding`.

They may be stored together on a given substrate, but one does not semantically imply the other.

**Next:** open-resource/access state is also physically bundled near activity state in both donors. Does it belong to continuation, or is resource-access binding independently mutable and future-relevant?
