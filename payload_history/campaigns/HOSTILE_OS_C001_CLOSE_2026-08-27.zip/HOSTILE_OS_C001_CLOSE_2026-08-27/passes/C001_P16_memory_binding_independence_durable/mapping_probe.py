#!/usr/bin/env python3
# Same logical IP/offset, different mapping/base -> different fetched byte/future.
mem={0x1000:0x90,0x2000:0xCC}
ip=0x10
base_a=0x0ff0;base_b=0x1ff0
fa=mem[base_a+ip];fb=mem[base_b+ip]
assert fa!=fb
open('evidence/MAPPING_WITNESS.txt','w').write(f'ip={ip:#x}\nbase_a={base_a:#x} fetched={fa:#x}\nbase_b={base_b:#x} fetched={fb:#x}\ndifferent_future=TRUE\n')
print('different_future=TRUE')
