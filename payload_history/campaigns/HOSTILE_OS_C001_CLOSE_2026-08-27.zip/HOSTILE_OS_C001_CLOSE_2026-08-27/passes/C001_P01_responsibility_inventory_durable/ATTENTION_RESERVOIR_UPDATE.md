# Attention Reservoir update after P01

- Idle identity discriminator: Linux task0 special state vs FreeDOS `sti; hlt`.
- Access-state decomposition: resource identity/backing vs access binding/mode vs cursor vs authority.
- Shared read/write surface: deep invariant vs compatibility convenience vs capability-polymorphic operation.
- UNKNOWN-cause taxonomy: absent target vs unsupported target vs unauthorized target vs stale/unbound target.
- Linux update child: isolate writeback responsibility from mere coexistence if later needed.
- FreeDOS simultaneous activity: do not infer absence from the sequential fixture; test only if a later discriminator requires it.
- Ontology burden: count independent state dimensions and semantic coupling, not subsystem names.
