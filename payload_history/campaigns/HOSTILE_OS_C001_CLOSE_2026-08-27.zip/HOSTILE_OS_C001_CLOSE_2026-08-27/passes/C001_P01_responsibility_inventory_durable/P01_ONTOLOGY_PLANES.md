# P01 ontology-plane audit

- **Identity:** Linux task identity persists across running/sleeping; FreeDOS current PSP changes across child transfer while parent context remains recoverable.
- **Binding:** command/path/resource lookup is separate from whether the requested operation later succeeds.
- **Applicability:** same read/write surface dispatches differently by backing type; seek on some device types has special semantics.
- **Capability:** readable/writable/executable behavior depends on current target and mode, not label alone.
- **Authority:** P01 did not discriminate permission from capability except basic access modes; preserve UNKNOWN where not tested.
- **Eligibility/currentness:** explicit in Linux runnable/sleep states; less directly exposed in sequential FreeDOS fixture.
- **Resource claim:** memory, file handles/access entries, buffers, device queues exist; exact scarcity policy not measured in P01.
- **State transition:** wait->wake, create->persisted, parent->child->parent, unresolved binding->bounded error all observed.
- **External consequence:** screen markers, disk-byte change, reboot retention, and blocked/resumed input are observation authority.
- **History/provenance:** first-boot CREATED remains historical after second-boot PREEXIST; current existence does not erase creation history.
- **UNKNOWN cause:** simultaneous FreeDOS user activity, exact Linux persistence flush actor, exact FreeDOS IRQ path, and pure-idle runtime entry remain unresolved.
