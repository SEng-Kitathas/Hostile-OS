# Discriminator revealed for C001 / P02

**Question:** Are execution identity, continuation lineage, and CPU eligibility/arbitration independent state relations under the P01 workloads, or does Linux require them to remain bundled to preserve observable behavior?

Why this follows from P01:
- both donors preserve parent/child continuation;
- both donors preserve wait/wake;
- only Linux P01 evidence requires simultaneously live task eligibility plus recurring arbitration;
- FreeDOS demonstrates that child lineage/return alone does not imply simultaneous CPU arbitration.

P02 must attack the separability, not assume a scheduler replacement.
