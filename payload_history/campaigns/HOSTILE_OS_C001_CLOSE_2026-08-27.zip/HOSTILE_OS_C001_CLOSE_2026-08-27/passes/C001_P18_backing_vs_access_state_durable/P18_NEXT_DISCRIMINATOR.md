# C001 / P19 discriminator
Is the common read/write surface a deep invariant requiring one universal file object, or a capability-polymorphic operation family whose legal effect depends on backing and access state?
