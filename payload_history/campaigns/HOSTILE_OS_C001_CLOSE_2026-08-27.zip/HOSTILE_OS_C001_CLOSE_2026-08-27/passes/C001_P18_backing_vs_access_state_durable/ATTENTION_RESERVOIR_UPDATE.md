# Attention Reservoir after P18
- Backing != per-access cursor/mode in both donors.
- Shared access operations may be compositional capability surface rather than universal object essence.
- Test applicability/backing dispatch before synthesis.
