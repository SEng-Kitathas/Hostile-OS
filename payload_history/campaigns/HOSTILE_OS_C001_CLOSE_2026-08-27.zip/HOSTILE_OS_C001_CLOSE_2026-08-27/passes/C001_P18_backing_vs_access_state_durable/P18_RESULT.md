# C001 / P18 — Backing/resource vs per-access state

**Disposition:** SPLIT-SUPPORTED / CROSS-DONOR CONVERGENCE  
**Scientific pass:** 18

Linux explicitly separates per-open `struct file` (`f_mode`, `f_flags`, `f_inode`, `f_pos`) from the inode/backing object. FreeDOS SFT likewise carries current position/open mode alongside a backing device/DCB or device-driver relation.

The future distinction is direct: two accesses bound to the same bytes but with different cursors return different next data. Same backing does not determine access position. Changing a cursor need not change backing identity.

So a single primitive "file" state loses a real relation. Minimum candidate decomposition:

`access binding -> backing/resource`  
`access binding -> cursor`  
`access binding -> mode/authority/applicability`

This is not yet a universal file architecture; it is a cross-donor split earned by future behavior.

**Next:** both donors expose read/write-like operations over regular storage, devices, pipes/remote paths. Is that shared surface evidence of one deep object type, or a capability-polymorphic operation family whose applicability depends on backing?
