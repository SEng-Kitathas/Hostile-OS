#!/usr/bin/env python3
resource=b'ABCDEFGH'
def read(pos,n=2):return resource[pos:pos+n],pos+n
a=read(0);b=read(4)
assert a[0]!=b[0]
open('evidence/CURSOR_WITNESS.txt','w').write(f'same_backing={resource!r}\naccess_A_pos0_read={a[0]!r}\naccess_B_pos4_read={b[0]!r}\ndifferent_future=TRUE\n')
print('different_future=TRUE')
