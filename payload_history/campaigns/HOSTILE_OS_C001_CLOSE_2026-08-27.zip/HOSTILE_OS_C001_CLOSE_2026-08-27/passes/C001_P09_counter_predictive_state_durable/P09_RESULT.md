# C001 / P09 — Counter predictive-state compression

**Disposition:** NO-COARSE-MERGE under tested arbitration contexts  
**Scientific pass:** 9

For priorities 1..8, every integer counter value in the derived envelope `0..2p-1` is reachable using only donor-valid events: service consumption and replenishment while non-consuming/blocked.

For every pair of distinct reachable counter values, the probe found a competing counter value for which the next chosen activity differs under Linux's strict-`>` high-slot scan. For p=4, all 28 pairs among 0..7 are distinguishable.

So numeric differences in the counter are not decorative under the full bounded arbitration context. Collapsing the scalar to coarse bins such as `empty/base/boosted` can change future execution order.

This does **not** prove that the historical cause of a counter value must be stored. It only shows the current magnitude itself is future-relevant.

**Next:** test whether different histories that converge to the same current counter can be merged safely. If yes, current counter is a sufficient predictive state for this responsibility and history provenance need not become a second scheduler state plane.
