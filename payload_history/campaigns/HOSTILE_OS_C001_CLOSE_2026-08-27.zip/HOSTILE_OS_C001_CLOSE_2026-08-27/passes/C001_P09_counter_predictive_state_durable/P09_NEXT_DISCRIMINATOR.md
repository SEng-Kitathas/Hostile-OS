# C001 / P10 discriminator
When different service/block/replenishment histories converge to the same current `(counter, priority, eligibility, tie rank)`, can those histories be merged without changing any future arbitration consequence?
