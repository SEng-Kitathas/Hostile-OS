# Attention Reservoir after P09
- Counter magnitude is future-relevant; coarse bins lose possible choices.
- Test history-provenance merge before adding an explicit history state.
- Preserve distinction: current predictive state vs historical evidence/provenance.
