#!/usr/bin/env python3
import json

def pick(a,b,p=4):
    # A rank low=1, B rank high=2; exact strict > scan high rank first
    ca,cb=a,b
    while True:
        c=-1;win=None
        # B then A
        if cb>c:c=cb;win='B'
        if ca>c:c=ca;win='A'
        if c:return win
        ca=(ca>>1)+p;cb=(cb>>1)+p

def reachable(p):
    bound=2*p-1
    seen={p};front=[p]
    # allowed semantic events: consume one tick if c>0; replenishment while blocked/non-consuming
    for _ in range(64):
        new=set(seen)
        for c in seen:
            if c>0:new.add(c-1)
            new.add((c>>1)+p)
        if new==seen:break
        seen=new
    return sorted(x for x in seen if 0<=x<=bound)

res={}
for p in range(1,9):
    vals=reachable(p);bound=2*p-1
    witnesses={};merged=[]
    for i,c in enumerate(vals):
      for d in vals[i+1:]:
        w=None
        for b in vals:
          if pick(c,b,p)!=pick(d,b,p):w={'competitor_counter':b,'winner_low':pick(c,b,p),'winner_high':pick(d,b,p)};break
        if w:witnesses[f'{c}:{d}']=w
        else:merged.append([c,d])
    res[p]={'bound':bound,'reachable':vals,'all_envelope_reachable':vals==list(range(bound+1)),
            'pair_count':len(vals)*(len(vals)-1)//2,'distinguished_pairs':len(witnesses),'undistinguished_pairs':merged,'sample_witnesses':dict(list(witnesses.items())[:20])}
json.dump(res,open('evidence/STATE_DISTINGUISHABILITY.json','w'),indent=2)
print(json.dumps({p:{k:v for k,v in d.items() if k not in ('sample_witnesses',)} for p,d in res.items()},indent=2))
