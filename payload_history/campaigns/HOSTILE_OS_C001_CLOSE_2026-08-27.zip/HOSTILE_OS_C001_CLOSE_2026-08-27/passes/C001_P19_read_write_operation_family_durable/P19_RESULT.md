# C001 / P19 — Read/write surface: invariant or operation family?

**Disposition:** CAPABILITY-POLYMORPHIC FAMILY SURVIVES; UNIVERSAL FILE ESSENCE REJECTED  
**Scientific pass:** 19

Linux `sys_read/sys_write` dispatches by backing kind: pipe, character device, block device, directory/regular file, with different position and legality rules. FreeDOS `DosRWSft` similarly dispatches remote, device, cooked/binary console/null behavior, or block/file transfer. Seek is explicitly special/inapplicable for some backing types.

The shared surface therefore does **not** prove one universal file mechanism. What survives is a narrower invariant:

`operation request + access state + backing capabilities -> applicable transfer consequence or bounded failure`.

`read` and `write` are useful common verbs because many backings expose byte-transfer capability, but applicability and state transitions remain backing-specific. Same label != same mechanism; different backing != necessarily different operation interface.

This supports capability composition without granting a universal `File` primitive.

**Next / P20 hard stop:** reconcile the full 20-pass campaign. What minimum independent relations have actually survived, which donor mechanisms remain optional capability, which scars must be carried forward, and what next campaign discriminator follows without architecture promotion?
