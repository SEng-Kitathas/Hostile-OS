# C001 / P20 discriminator
Reconcile C001 into the minimum independent relation set actually earned by P01-P19, preserve scars/optional capabilities/UNKNOWNs, run CSC shadow audit, and select the next campaign frontier without promoting an architecture.
