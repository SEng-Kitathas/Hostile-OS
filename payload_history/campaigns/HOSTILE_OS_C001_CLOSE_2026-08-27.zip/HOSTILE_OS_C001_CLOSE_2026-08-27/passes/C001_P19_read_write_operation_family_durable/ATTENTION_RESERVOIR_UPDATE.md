# Attention Reservoir after P19
- Candidate independent relations now span eligibility/arbitration, continuation, memory binding, resource access, backing, cursor/mode/applicability.
- P20 must reconcile rather than extend.
- Deferred fronts: idle identity, event provenance, persistence/recovery semantics, namespace/binding, authority, UNKNOWN causes, multicore/energy/latency stress, broader hardware.
