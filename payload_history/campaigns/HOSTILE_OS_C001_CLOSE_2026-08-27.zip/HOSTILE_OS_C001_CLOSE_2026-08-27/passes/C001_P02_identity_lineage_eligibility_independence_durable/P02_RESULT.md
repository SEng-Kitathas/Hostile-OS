# C001 / P02 — Identity, lineage, eligibility, and arbitration independence

**Disposition:** SURVIVED / NARROWED  
**Scientific pass:** 2

## Question

Are execution identity, continuation lineage, and CPU eligibility/arbitration independent state relations under the P01 workloads, or does Linux require them to remain bundled to preserve observable behavior?

## Result

**Semantic independence is earned. Physical representation separation is not yet earned.**

Linux 0.01 stores several of these dimensions in one `task_struct`, but its own transitions operate on them independently:

- `wake_up()` changes the waiting task's `state` to runnable and clears the wait-queue binding. It does not change PID, parent relation, counter, or priority.
- scheduler selection reads runnable `state` and `counter`; counter replenishment uses `counter` and `priority`. PID and `father` are not selection inputs.
- `copy_process()` creates identity (`pid`), lineage (`father`), eligibility (`state`), and budget (`counter`) together at birth, but later functions mutate/read those dimensions independently.
- `do_exit()` can preserve identity as a zombie while changing execution eligibility/state and notifying the recorded father.
- `waitpid()` first identifies children by lineage/identity, then separately tests child state. If the child relation exists but no child has reached the required state, the parent changes its own eligibility through `sys_pause()`.

FreeDOS supplies the hostile counterexample to “lineage implies arbitration”:

- child load/transfer records `ps_parent` / `ps_prevpsp`, saves the parent stack, changes `cu_psp`, and transfers control;
- `return_user()` later restores `cu_psp` from `ps_parent` and resumes the saved parent stack;
- this path carries lineage and continuation without using Linux-style runnable-set selection, counters, or priority arbitration.

## Transition independence matrix

| Relation | Linux witness | FreeDOS witness | P02 result |
|---|---|---|---|
| execution identity | PID/task slot persists across running, sleeping, zombie states | PSP referent identifies current/parent execution context | independent from eligibility |
| continuation lineage | `father`, wait/exit relation | `ps_parent`, `ps_prevpsp`, saved stack | independent from CPU arbitration |
| eligibility | `state` changes RUNNING <-> INTERRUPTIBLE/ZOMBIE while identity remains | sequential fixture exposes wait/return but not a Linux-like runnable set | distinct from identity; FreeDOS simultaneous eligibility remains UNKNOWN |
| arbitration budget | `counter`, `priority` used by scheduler | absent from demonstrated child transfer/return path | not required merely to preserve lineage |
| wait binding | tty wait queue points at identifiable task; `wake_up` clears binding and changes state | current call waits on input/device consequence | distinct relation from lineage |

## Hostile merge tests

### Merge identity with eligibility — REJECTED
If “not runnable” meant “no identity,” Linux could not retain the blocked continuation that the keyboard event later wakes, nor retain zombie child state for the parent to reap. P01 directly observed wait -> wake continuation.

### Merge lineage with eligibility — REJECTED
FreeDOS P01 child execution retains a parent-return relation while using sequential transfer. Linux `waitpid()` also queries lineage separately from state. Parentage does not determine which context currently owns CPU time.

### Merge lineage with arbitration — REJECTED
Linux scheduler selection does not consult `father`/PID. FreeDOS preserves parent/child return without the Linux selection mechanism.

### Merge eligibility with arbitration — REJECTED
Linux `wake_up()` makes a task runnable without selecting it. Selection happens later in `schedule()`. Becoming eligible and being chosen are separate consequences.

## What P02 does NOT establish

- It does not prove these relations should each become a separate ECS component, table, object, or primitive.
- It does not prove Linux's physical `task_struct` bundling is bad.
- It does not prove a dedicated scheduler is removable.
- It does not establish FreeDOS lacks every form of multitasking or task switching.
- It does not establish that PID or table slot is the right future identity representation.

## Scar exposed

Linux's scheduler uses **task-table position** during selection even though PID/lineage are not used. Equal-counter tie behavior is therefore influenced by scan order / slot position. That is a future-relevant distinction hidden in representation position, and it invokes the existing scar:

`vector/table position != identity`.

This scar becomes the next pressure point because an apparently minimal arbitration relation may secretly depend on positional state.
