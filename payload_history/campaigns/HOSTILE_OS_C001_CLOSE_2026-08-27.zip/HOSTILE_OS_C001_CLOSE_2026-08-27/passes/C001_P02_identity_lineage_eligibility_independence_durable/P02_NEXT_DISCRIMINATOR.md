# C001 / P03 discriminator

**Question:** What information does Linux 0.01 compute arbitration actually require beyond (1) current eligibility, (2) per-activity budget/priority, and (3) an explicit tie/fallback rule; and is task-table position a future-relevant hidden input?

P03 must preserve exact Linux selection behavior first, then expose any hidden state used by that behavior. It may not replace the scheduler or assume the position dependence is removable.
