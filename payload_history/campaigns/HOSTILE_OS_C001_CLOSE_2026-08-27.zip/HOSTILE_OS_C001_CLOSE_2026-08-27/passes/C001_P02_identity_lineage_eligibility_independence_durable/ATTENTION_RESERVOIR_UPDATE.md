# Reservoir after P02

- Representation bundling vs semantic independence: separate question; do not force one-structure-per-relation.
- Linux task slot as tie-break state: position is behaviorally relevant until disproven.
- Zombie identity: identity can remain after execution eligibility is permanently gone; useful discriminator for lifecycle semantics.
- FreeDOS sequential lineage: parent/child relation survives without simultaneous user eligibility.
- FreeDOS PCB/task-switch support remains uncharacterized; do not infer global absence from P01 fixture.
