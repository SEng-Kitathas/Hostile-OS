# C001 / P15 discriminator
Must continuation state be physically/ontologically embedded in an activity identity object, or can identity bind to a separate continuation carrier without losing suspend/resume behavior?
