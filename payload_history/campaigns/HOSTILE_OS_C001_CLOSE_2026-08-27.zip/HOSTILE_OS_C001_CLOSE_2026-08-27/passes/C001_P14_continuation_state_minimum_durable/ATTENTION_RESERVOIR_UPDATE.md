# Attention Reservoir after P14
- Common continuation core survived; full Linux task_struct did not.
- Capability-conditioned context extensions matter.
- Test binding vs embedding next; do not turn a convenient struct layout into ontology.
