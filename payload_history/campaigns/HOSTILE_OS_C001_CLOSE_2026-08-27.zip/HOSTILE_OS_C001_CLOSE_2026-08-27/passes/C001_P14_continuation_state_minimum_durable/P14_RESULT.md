# C001 / P14 — Minimum continuation state

**Disposition:** COMMON CORE + SUBSTRATE-CONDITIONAL EXTENSIONS  
**Scientific pass:** 14

Linux 0.01 and FreeDOS carry continuation very differently, but their overlap is sharp: to resume execution, some representation must preserve **instruction position, stack position, live machine/register state, condition/flags state, and the binding needed to interpret code/data**.

Linux's hardware TSS additionally carries privilege stacks, page-table binding, LDT selector, trace bitmap, and lazy i387 state. FreeDOS's saved interrupt/register frame is much smaller. This proves the large Linux `task_struct` is not itself the minimum continuation invariant.

Fields such as identity, parentage, open files, and arbitration priority are not required *inside* the continuation snapshot. They may affect execution, but they are separate relations.

Continuation size is capability/substrate dependent: floating-point or privilege transition state exists only when the execution capability needs it.

**Next:** does the continuation snapshot have to be embedded in the activity identity object, or can identity bind to a separate opaque continuation carrier?
