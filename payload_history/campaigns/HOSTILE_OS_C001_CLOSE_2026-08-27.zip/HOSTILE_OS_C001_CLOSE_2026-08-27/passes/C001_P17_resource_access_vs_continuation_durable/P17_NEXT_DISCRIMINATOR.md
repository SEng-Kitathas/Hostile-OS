# C001 / P18 discriminator
Are resource backing/identity and per-access state (cursor/mode/binding) future-distinguishable, or can a single generic "file" state represent both without losing behavior?
