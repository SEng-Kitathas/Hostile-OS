# C001 / P17 — Resource access is not continuation core

**Disposition:** SPLIT-SUPPORTED  
**Scientific pass:** 17

Linux places `filp[]` and the TSS in the same `task_struct`, but they are separate fields with separate mutation paths; close/exec can change file bindings while the activity remains the same execution identity. FreeDOS likewise keeps process file-handle bindings in PSP/JFT state while execution resume uses saved register/stack context.

Therefore open-resource state is not part of the minimum continuation snapshot. The future-relevant relation is separate:

`activity -> access handle/binding -> access state/resource`.

Continuation answers "where/how can execution resume?" Resource binding answers "what external resource does this operation refer to?" Collapsing them would confuse execution state with authority/access state.

**Next:** inside resource access itself, must backing/resource identity and per-access cursor/mode remain distinct?
