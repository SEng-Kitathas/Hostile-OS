# Attention Reservoir after P17
- Continuation and resource access are separate planes.
- File/access quarry is now lawfully connected by the prior discriminator, not a random pivot.
- Test per-access cursor vs backing identity next.
