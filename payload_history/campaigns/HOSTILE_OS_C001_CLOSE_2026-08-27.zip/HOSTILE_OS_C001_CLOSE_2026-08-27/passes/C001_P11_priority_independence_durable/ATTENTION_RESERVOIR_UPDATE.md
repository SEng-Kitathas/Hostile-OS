# Attention Reservoir after P11
- Priority and current credit are independent.
- Next distinguish required P01 invariant from extra donor capability.
- Do not promote priority into minimal substrate merely because Linux exposes it.
