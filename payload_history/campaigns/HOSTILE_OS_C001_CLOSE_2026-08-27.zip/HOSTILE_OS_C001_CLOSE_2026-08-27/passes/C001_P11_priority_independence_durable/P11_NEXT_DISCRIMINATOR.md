# C001 / P12 discriminator
Does heterogeneous replenishment weight/priority buy any behavior required by the qualified P01 workload, or can P01 be satisfied with equal-weight bounded arbitration while retaining priority as an optional donor capability?
