# C001 / P11 — Priority is independent from current credit

**Disposition:** SPLIT-SUPPORTED  
**Scientific pass:** 11

Equal current counters do not make different priorities future-equivalent. At counter 0, the next replenishment uses `priority`; for every tested priority pair 1..8, a competitor can be chosen so the next winner differs solely because priority differs.

Canonical source gives a second witness: `sys_nice()` mutates `current->priority` without changing identity, lineage, or current counter directly. Priority is therefore a mutable service-weight relation, not an identity property.

So `current service credit` and `replenishment weight` are independent state dimensions even though both are integers and jointly shape arbitration.

**Next:** does heterogeneous priority buy anything required by the qualified P01 workload, or is it donor capability beyond the minimum invariant currently under test?
