#!/usr/bin/env python3
import json
# Witness: same current counter 0, same eligibility/rank; competitor priority equal to lower p and high tie rank.
def first_after_replenish(pa,pb,comp_p):
    ca=0; cb=0
    ca=(ca>>1)+pa; cb=(cb>>1)+comp_p
    # competitor B high rank; strict > means tie goes B
    return 'A' if ca>cb else 'B',ca,cb
w={}
for p1 in range(1,8):
 for p2 in range(p1+1,9):
  comp=p1
  a=first_after_replenish(p1,0,comp);b=first_after_replenish(p2,0,comp)
  assert a[0]!=b[0]
  w[f'{p1}:{p2}']={'competitor_priority':comp,'winner_low_priority':a[0],'winner_high_priority':b[0],'credits_low':a[1:],'credits_high':b[1:]}
json.dump(w,open('evidence/PRIORITY_WITNESSES.json','w'),indent=2)
print('pairs',len(w),'all_distinguished',True)
