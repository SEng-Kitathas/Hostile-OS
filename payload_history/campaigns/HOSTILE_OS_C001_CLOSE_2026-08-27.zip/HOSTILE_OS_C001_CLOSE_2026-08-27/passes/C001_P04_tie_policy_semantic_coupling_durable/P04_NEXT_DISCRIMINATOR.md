# C001 / P05 discriminator

**Question:** What capability do Linux 0.01's per-task counter and priority/replenishment rules buy, beyond bounded progress that could be provided by a simpler eligible-set + quantum/rotation policy?

P05 must compare at least progress, starvation, response latency, and behavior under block/wake. It may not call “fewer fields” better unless equivalent required capability is demonstrated.
