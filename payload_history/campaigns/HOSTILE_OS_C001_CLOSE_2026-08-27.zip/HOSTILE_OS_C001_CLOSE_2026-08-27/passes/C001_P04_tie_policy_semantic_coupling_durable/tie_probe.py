#!/usr/bin/env python3
from dataclasses import dataclass, replace
from itertools import permutations
from pathlib import Path
import json,csv
OUT=Path(__file__).resolve().parent
@dataclass
class T:
    ident:str
    slot:int
    rank:int
    counter:int
    priority:int
    remaining:int
    runnable:bool=True

def pick(tasks,policy,last=None):
    elig=[t for t in tasks if t.runnable and t.remaining>0]
    if not elig:return None
    maxc=max(t.counter for t in elig)
    if maxc==0:
        for t in tasks:t.counter=(t.counter>>1)+t.priority
        elig=[t for t in tasks if t.runnable and t.remaining>0]
        maxc=max(t.counter for t in elig)
    tied=[t for t in elig if t.counter==maxc]
    if policy=='slot_high': return max(tied,key=lambda t:t.slot)
    if policy=='explicit_rank': return max(tied,key=lambda t:t.rank)
    if policy=='identity': return min(tied,key=lambda t:t.ident)
    if policy=='round_robin':
        ordered=sorted(tied,key=lambda t:t.rank)
        if last is None:return ordered[0]
        for t in ordered:
            if t.rank>last:return t
        return ordered[0]
    raise ValueError(policy)

def run(tasks,policy,limit=1000):
    tasks=[replace(t) for t in tasks]; seq=[]; first={}; done={}; last=None
    for tick in range(limit):
        if all(t.remaining<=0 for t in tasks):break
        cur=pick(tasks,policy,last)
        if cur is None:break
        first.setdefault(cur.ident,tick)
        seq.append(cur.ident)
        cur.remaining-=1; cur.counter=max(0,cur.counter-1)
        if cur.remaining==0: done[cur.ident]=tick+1
        if policy=='round_robin': last=cur.rank
    return {'sequence':''.join(seq),'first':first,'done':done,'ticks':len(seq)}

# Equal-work bounded contention: all policies should provide bounded completion.
base=[T('A',1,1,3,3,6),T('B',2,2,3,3,6),T('C',3,3,3,3,6)]
policies=['slot_high','explicit_rank','identity','round_robin']
results={p:run(base,p) for p in policies}

# Exact-behavior preservation: explicit rank set to original slot rank reproduces slot policy.
exact_match=results['slot_high']['sequence']==results['explicit_rank']['sequence']

# Relocation probe: swap only storage slots after tie ranks were assigned.
relocated=[T('A',3,1,5,5,3),T('B',2,2,5,5,3),T('C',1,3,5,5,3)]
original=[T('A',1,1,5,5,3),T('B',2,2,5,5,3),T('C',3,3,5,5,3)]
rel={
 'original_slot':run(original,'slot_high'),
 'relocated_slot':run(relocated,'slot_high'),
 'original_explicit':run(original,'explicit_rank'),
 'relocated_explicit':run(relocated,'explicit_rank'),
}

# Exhaust all 3! slot permutations for same logical tasks / stable ranks.
perm=[]
for slots in permutations([1,2,3]):
    ts=[T(name,slot,rank,4,4,2) for (name,rank),slot in zip([('A',1),('B',2),('C',3)],slots)]
    perm.append({'slots':slots,'slot_winner':pick([replace(t) for t in ts],'slot_high').ident,'explicit_winner':pick([replace(t) for t in ts],'explicit_rank').ident})

summary={
 'bounded_contention':results,
 'explicit_rank_reproduces_original_slot_policy':exact_match,
 'relocation':rel,
 'permutations':perm,
 'slot_policy_changes_under_relocation':rel['original_slot']['sequence']!=rel['relocated_slot']['sequence'],
 'explicit_policy_stable_under_relocation':rel['original_explicit']['sequence']==rel['relocated_explicit']['sequence'],
}
(OUT/'evidence'/'TIE_POLICY_SUMMARY.json').write_text(json.dumps(summary,indent=2))
with (OUT/'evidence'/'PERMUTATION_PROBE.tsv').open('w',newline='') as f:
    w=csv.writer(f,delimiter='\t'); w.writerow(['slot_A','slot_B','slot_C','slot_policy_winner','explicit_rank_winner']);
    for x in perm:w.writerow([*x['slots'],x['slot_winner'],x['explicit_winner']])
print(json.dumps(summary,indent=2))
