# C001 / P04 — Tie policy and semantic coupling

**Disposition:** NARROWED / CONTEXT-DEPENDENT  
**Scientific pass:** 4

## Question

Does Linux 0.01's position-derived tie order buy any required capability under bounded competing-activity workloads, or is it accidental semantic coupling that can be replaced by an explicit lower-coupling tie relation without losing required behavior?

## Result

The answer splits cleanly:

1. **A tie rule is real behavior.** Equal-budget activities still require a deterministic or otherwise lawful choice.
2. **Storage position is not semantically required to provide that rule.** An explicit stable rank set to the original slot order reproduces the position-derived policy exactly in the bounded model.
3. **Position-derived rank is cheaper in metadata.** If the table order is already stable and no relocation/compaction semantics are required, it gets deterministic ties “for free.”
4. **Explicit rank buys a real capability:** storage slots may be rearranged without silently changing equal-budget execution order.

Therefore position-derived ranking is neither a deep invariant nor automatically “bad.” It is a **representation coupling with a real Pareto trade**.

## Bounded contention probe

Three equal-priority, equal-counter activities with finite work were run under four tie policies: Linux-like high-slot order, explicit stable rank, identity order, and round-robin rank. All completed all finite work in the bounded test. Tie policy changed **who moved first and intermediate latency**, not whether finite work could complete.

The explicit-rank policy configured with the original slot ranks produced the same sequence as the slot-derived policy. This shows the donor's behavior can be preserved without storage position itself carrying the meaning.

## Relocation probe

Only the physical slots of A/B/C were permuted; logical identity, counter, priority, remaining work, and explicit rank were held constant.

- position-derived policy changed the winner/sequence when slots changed;
- explicit stable rank preserved the winner/sequence across relocation;
- all 3! slot permutations confirmed the same distinction.

So table position carries a hidden contract:

`move representation -> potentially change execution order`.

That contract is future-relevant, but P01 did not require representation mobility. P04 therefore cannot reject it on principle.

## Pareto result

| Tie source | Added metadata | Storage-order coupling | Stable under relocation | P04 status |
|---|---:|---:|---:|---|
| table position | none beyond table | yes | no | nondominated when fixed layout is acceptable |
| explicit stable rank | at least one rank relation | no | yes | nondominated when mobility/compaction matters |

“Explicit is cleaner” is not enough. The extra relation has to buy the relocation/stability capability in a context that needs it.

## Hostile conclusions

- **Position order is a required invariant:** REJECTED.
- **Some tie consequence is required:** SURVIVED.
- **Explicit tie rank is always better:** REJECTED.
- **Storage order is harmless implementation detail:** REJECTED; it changes behavior.
- **P01 workloads need relocation-stable tie order:** UNRESOLVED / not demonstrated.

## New pressure

With lineage removed from the chooser and tie semantics isolated, most of Linux's recurring arbitration machinery now reduces to **eligibility + counter + replenishment priority + tie/fallback**. The next high-information question is whether counter/priority state buys enough capability to justify itself compared with simpler bounded-progress policies.
