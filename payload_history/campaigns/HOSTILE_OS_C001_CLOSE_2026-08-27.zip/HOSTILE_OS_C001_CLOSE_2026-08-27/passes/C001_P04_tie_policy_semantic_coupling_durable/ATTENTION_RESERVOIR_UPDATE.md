# Reservoir after P04

- Tie policy should be selected by required semantics, not aesthetics.
- Representation mobility/compaction is a capability that can justify explicit rank metadata.
- Deterministic order itself may matter for replay/assurance later; not tested here.
- Identity-derived ordering could create a different coupling; do not substitute automatically.
- Counter/priority now becomes the next burden/capability target.
