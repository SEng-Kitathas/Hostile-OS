# Attention Reservoir at C001 hard stop

Priority for C002:
1. Whole-P01 donor-neutral relation representation and ontology-leak attack.
2. Minimal executor as composition, not scheduler noun.
3. Wait/wake/event provenance and currentness.
4. Persistence/restart requalification and recovery.
5. Authority/applicability separation in resource operations.

Preserved sibling fronts after C002 opening:
- idle identity necessity;
- namespace/binding derivation;
- multicore/coherency/priority inversion;
- deadlines and interactive latency;
- energy/thermal Pareto dimensions;
- security/isolation;
- broader hardware/device ecology;
- exact per-access vs backing composition across pipes/devices/remote resources.
