#!/usr/bin/env python3
from pathlib import Path
import re,subprocess,json,sys
base=Path('/mnt/data/hostile_os_lab_live/runs')
rows=[];errors=[];warnings=[]
for n in range(1,20):
    matches=sorted(base.glob(f'C001_P{n:02d}_*'))
    # prefer durable scientific dirs, ignore older lowercase infrastructure dirs
    matches=[p for p in matches if (p/'receipt.txt').exists() and 'SCIENTIFIC_C001' in (p/'receipt.txt').read_text(errors='ignore')]
    if len(matches)!=1:
        errors.append(f'P{n:02d}: expected one scientific directory, found {len(matches)}: {[p.name for p in matches]}')
        continue
    p=matches[0];rec=(p/'receipt.txt').read_text(errors='replace')
    marker=(p/'COMPLETION.marker').read_text().strip() if (p/'COMPLETION.marker').exists() else None
    m=re.search(r'scientific_pass_count_after=(\d+)',rec)
    count=int(m.group(1)) if m else None
    hash_ok=None
    if (p/'result_hashes.txt').exists():
        cp=subprocess.run(['sha256sum','-c','result_hashes.txt'],cwd=p,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        hash_ok=(cp.returncode==0)
        if not hash_ok:errors.append(f'P{n:02d}: result_hashes verification failed')
    else:errors.append(f'P{n:02d}: missing result_hashes.txt')
    if marker!='COMPLETE':errors.append(f'P{n:02d}: completion marker {marker!r}')
    if count!=n:errors.append(f'P{n:02d}: count_after={count}')
    next_file=next(iter(p.glob(f'P{n:02d}_NEXT_DISCRIMINATOR.md')),None)
    if n<19 and next_file is None:warnings.append(f'P{n:02d}: no named next-discriminator file')
    rows.append({'pass':n,'dir':p.name,'marker':marker,'count_after':count,'hash_ok':hash_ok,'has_next':next_file is not None})
# special scars
p5=next(base.glob('C001_P05_*'))
scar=(p5/'HARNESS_SCAR_001.md').exists() and any((p5/'evidence').glob('INVALID_*'))
if not scar:errors.append('P05 invalid harness scar not preserved')
# no accidental P21 scientific pass
p21=[p for p in base.glob('C001_P21_*') if (p/'receipt.txt').exists()]
if p21:errors.append(f'Unexpected P21 artifacts: {[p.name for p in p21]}')
result={'authority':'SHADOW_AUDIT_ONLY','promotion_authority':'NONE','rows':rows,'errors':errors,'warnings':warnings,'p05_scar_preserved':scar,'pass':not errors}
Path('evidence/CSC_AUDIT.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
sys.exit(0 if not errors else 2)
