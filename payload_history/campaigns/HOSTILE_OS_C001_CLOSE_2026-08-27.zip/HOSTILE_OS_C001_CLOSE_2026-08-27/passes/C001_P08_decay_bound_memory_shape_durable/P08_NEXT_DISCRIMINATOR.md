# C001 / P09 discriminator
Which Linux 0.01 counter magnitudes are future-behavior distinguishable under bounded arbitration/block-wake continuations, and can any values be merged without changing reachable scheduling consequences?
