#!/usr/bin/env python3
import json
out={}
for p in range(1,33):
    vals=[];c=p
    for n in range(16):
        vals.append(c);c=(c>>1)+p
    bound=2*p-1
    out[p]={'sequence':vals,'theoretical_bound':bound,'max_seen':max(vals),'stable':vals[-1]==bound}
    assert all(v<=bound for v in vals)
    # exhaustive closure from every admissible c in [0,bound]
    assert all(((c>>1)+p)<=bound for c in range(bound+1))
# Compare path against hard saturation to 2p-1 from initial p
pathdiff={}
for p in [1,2,3,4,8,16]:
    l=[];a=[];cl=p;ca=p;cap=2*p-1
    for _ in range(8):
        l.append(cl);a.append(ca)
        cl=(cl>>1)+p;ca=min(cap,ca+p)
    pathdiff[p]={'linux':l,'hardcap_add':a,'equal':l==a}
json.dump({'recurrences':out,'path_comparison':pathdiff},open('evidence/RECURRENCE.json','w'),indent=2)
print(json.dumps({'p4':out[4],'path_p4':pathdiff[4]},indent=2))
