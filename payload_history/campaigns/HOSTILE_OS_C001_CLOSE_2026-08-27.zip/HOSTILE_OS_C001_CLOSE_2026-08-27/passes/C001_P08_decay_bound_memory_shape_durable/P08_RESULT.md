# C001 / P08 — Decay bound and memory shape

**Disposition:** SURVIVED / DERIVED  
**Scientific pass:** 8

For positive priority `p`, Linux 0.01's replenishment recurrence

`c' = floor(c/2) + p`

has a closed invariant envelope `0 <= c <= 2p-1` once initialized in-range. Starting from `c=p`, a blocked/non-consuming task approaches that ceiling gradually. For `p=4`: `4 -> 6 -> 7 -> 7...`.

A hard additive cap at the same envelope has a different path: `4 -> 7 -> 7...`. P07's high-contention divergence is therefore explained by more than the maximum credit: Linux also preserves **graded recency/non-use history** through the approach path.

The half-decay is a compact leaky history filter: recent unused service matters; older unused service has diminishing weight; accumulated credit is bounded below `2*priority`.

This is an earned mechanism-level description, not a claim that the historical scalar is the only representation.

**Next:** test predictive-state compression of the counter. Which counter magnitudes are actually behaviorally distinguishable under bounded future workloads, and which can be merged without changing future choices?
