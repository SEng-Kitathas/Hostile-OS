# Attention Reservoir after P08
- Exact half-decay encodes graded bounded history, not merely a cap.
- Apply predictive-state split/merge law before inventing a separate history primitive.
- Test distinguishability by future consequences, not by numeric difference alone.
