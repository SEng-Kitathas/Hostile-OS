# C001 / P14 discriminator
What is the minimum future-relevant continuation state needed to suspend and later resume an activity, given Linux 0.01's large task context and FreeDOS's much smaller PCB/context carrier?
