#!/usr/bin/env python3
# Event-level model: shell S, resident update U, child C. Required P01 consequences only.
from collections import deque
import json
class A:
 def __init__(self,n,work=None):self.n=n;self.run=True;self.work=work;self.service=0;self.done=False

def rr(q=4,limit=200):
 S=A('S');U=A('U');C=A('C',3);qs=deque([S,U,C]);timeline=[];wait_child=True;wake_input_at=80;input_ready=False
 cur=None;left=0
 for t in range(limit):
  if t==wake_input_at:input_ready=True;S.run=True;qs.append(S) if S not in qs else None
  if cur is None or left==0 or not cur.run:
   if cur and cur.run and not cur.done:qs.append(cur)
   cur=None
   for _ in range(len(qs)):
    x=qs.popleft()
    if x.run and not x.done:cur=x;break
    qs.append(x)
   left=q
  if cur is None:continue
  cur.service+=1;timeline.append(cur.n);left-=1
  if cur is C:
   C.work-=1
   if C.work==0:C.done=True;C.run=False;wait_child=False;cur=None
  if cur is S:
   # after first service shell waits for child until C done; later block for input until tick80
   if wait_child and S.service>=1:S.run=False;cur=None
   elif not wait_child and S.service>=2 and not input_ready:S.run=False;cur=None
 # Parent wakes when child done
 if C.done:S.run=True
 # conservative consequence checks over finite run
 return {'child_done':C.done,'shell_service':S.service,'update_service':U.service,'child_service':C.service,'all_progress':S.service>0 and U.service>0 and C.done,'timeline_prefix':timeline[:40]}
for q in [1,2,4,8]:
 r=rr(q);assert r['all_progress'];json.dump(r,open(f'evidence/RR_Q{q}.json','w'),indent=2)
 print(q,r)
