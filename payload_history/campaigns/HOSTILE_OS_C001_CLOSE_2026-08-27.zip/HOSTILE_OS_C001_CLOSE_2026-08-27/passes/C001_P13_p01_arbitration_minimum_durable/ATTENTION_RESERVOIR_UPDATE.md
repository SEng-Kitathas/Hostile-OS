# Attention Reservoir after P13
- P01 earns bounded arbitration responsibility, not Linux's counter algorithm.
- Preserve graded-credit mechanism as qualified optional capability for later interactive/contended workloads.
- Shift next to continuation/context, the unresolved prerequisite exposed by suspension/resume.
