# C001 / P13 — Minimum arbitration demanded by P01

**Disposition:** GRADED CREDIT NOT EARNED AS P01 MINIMUM  
**Scientific pass:** 13

P01's observed consequences do not require a weighted or graded-history arbitration policy. A bounded equal-weight rotation with quanta 1/2/4/8 is sufficient in the event-level model to let a shell-like parent, resident update activity, and finite child all make progress and complete the child-return relation while allowing blocking/wake.

The model is not a claim that RR is globally adequate. P05-P08 already found workloads where Linux's graded history buys better response/fairness tradeoffs. The result is narrower: **P01 itself does not discriminate those policies.**

Therefore the minimum responsibility earned so far is:

`eligible set + lawful bounded arbitration + continuation/wake relation`

not `Linux counter algorithm`.

This is the campaign's composition-first boundary: donor mechanism capability is retained in the quarry, but it is not promoted into the minimum substrate without a workload that needs it.

**Next:** now that arbitration policy has been reduced to its required responsibility, what execution state must actually survive suspension so an activity can later continue? Compare the radically different Linux and FreeDOS continuation carriers.
