# Attention Reservoir after P07
- Bounded credit is a strong explanatory candidate; exact half-decay still matters in at least one high-contention case.
- Derive donor bound before proposing new mechanisms.
- Predictive-state minimization of counter magnitudes remains live.
- No promotion of a new scheduler architecture.
