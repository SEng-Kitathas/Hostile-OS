# C001 / P07 — Bounded service credit

**Disposition:** SURVIVED-AS-ALTERNATE-REPRESENTATION / NOT DOMINANT  
**Scientific pass:** 7

A single bounded additive service-credit scalar was tested against Linux 0.01's half-decay carry. When all runnable credit is exhausted, the alternate adds `priority` to every existing task and saturates at `K*priority`.

Across the bounded matrix, any cap >=2 reproduced Linux exactly in most scenarios and was much closer than no-carry. The main divergence appeared with 8 permanent hogs + 1 fast sleeper: cap-2 gave the sleeper more service and lower wake latency, with more switches, than Linux. Therefore the **existence of bounded non-use credit** explains much of the donor behavior, but the exact transition path still changes behavior under contention.

This rejects the idea that Linux's exact `counter >> 1` transform is uniquely required. It also rejects the idea that the bound alone fully determines behavior.

**Next:** derive the actual bound and approach-to-bound encoded by Linux's recurrence, then test whether the path carries future-relevant information beyond the envelope.
