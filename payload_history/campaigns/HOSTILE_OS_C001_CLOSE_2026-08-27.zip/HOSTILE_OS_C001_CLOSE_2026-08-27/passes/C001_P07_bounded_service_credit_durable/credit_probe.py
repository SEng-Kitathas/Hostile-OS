#!/usr/bin/env python3
from dataclasses import dataclass,field
import csv,json,math
@dataclass
class T:
 name:str; p:int=4; c:int=4; rank:int=0; kind:str='hog'; sleep:int=1; runnable:bool=True; service:int=0; wake_at:int|None=None; wake_tick:int|None=None; lats:list=field(default_factory=list)
class P:
 def __init__(self,mode,cap=None):self.mode=mode;self.cap=cap
 def pick(self,ts):
  while True:
   best=None;v=-1
   for x in sorted(ts,key=lambda z:z.rank,reverse=True):
    if x.runnable and x.c>v:v=x.c;best=x
   if v:return best
   for x in ts:
    if self.mode=='linux':x.c=(x.c>>1)+x.p
    elif self.mode=='capadd':x.c=min(self.cap*x.p,x.c+x.p)
    elif self.mode=='nocarry':x.c=x.p

def sim(mode,hogs,sleepers,sleep,cap=None,ticks=10000):
 ts=[T(f'H{i}',rank=i+1) for i in range(hogs)]+[T(f'S{j}',rank=hogs+j+1,kind='sleeper',sleep=sleep) for j in range(sleepers)]
 pol=P(mode,cap);cur=None;sw=0;last=None
 for t in range(ticks):
  for x in ts:
   if not x.runnable and x.wake_at is not None and t>=x.wake_at:
    x.runnable=True;x.wake_at=None;x.wake_tick=t
  if cur is None or not cur.runnable or cur.c<=0:
   cur=pol.pick(ts)
   if last!=cur.name:sw+=1
   last=cur.name
  cur.service+=1;cur.c-=1
  if cur.kind=='sleeper':
   if cur.wake_tick is not None:cur.lats.append(t-cur.wake_tick+1);cur.wake_tick=None
   cur.runnable=False;cur.wake_at=t+1+cur.sleep;cur=None
 hs=[x for x in ts if x.kind=='hog'];ss=[x for x in ts if x.kind=='sleeper'];lat=[z for x in ss for z in x.lats]
 return {'mode':mode if mode!='capadd' else f'cap{cap}','hogs':hogs,'sleepers':sleepers,'sleep':sleep,'min_hog':min((x.service for x in hs),default=0),'min_sleeper':min((x.service for x in ss),default=0),'avg_lat':round(sum(lat)/len(lat),3) if lat else None,'max_lat':max(lat) if lat else None,'switches':sw}
scenarios=[(3,1,1),(3,1,3),(8,1,1),(1,4,1),(1,8,1),(1,16,1),(1,8,3),(1,8,7)]
rows=[]
for sc in scenarios:
 for mode,cap in [('linux',None),('nocarry',None),('capadd',2),('capadd',3),('capadd',4),('capadd',8)]:rows.append(sim(mode,*sc,cap=cap))
with open('evidence/MATRIX.tsv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t');w.writeheader();w.writerows(rows)
# distance from linux over normalized key metrics, per policy
metrics=['min_hog','min_sleeper','avg_lat','max_lat','switches']
by={}
for r in rows:
 key=(r['hogs'],r['sleepers'],r['sleep']);by.setdefault(key,{})[r['mode']]=r
scores={}
for cand in ['nocarry','cap2','cap3','cap4','cap8']:
 s=0.0
 for key,d in by.items():
  a=d['linux'];b=d[cand]
  for m in metrics:
   av=a[m] or 0;bv=b[m] or 0;s+=abs(bv-av)/max(1,abs(av))
 scores[cand]=round(s,6)
with open('evidence/SCORES.json','w') as f:json.dump(scores,f,indent=2)
print(json.dumps(scores,indent=2))
for key in [(3,1,1),(1,8,1),(1,16,1)]:
 print('\n',key)
 for m,r in by[key].items():print(r)
