# C001 / P08 discriminator
What exact bound and memory shape does `counter <- (counter >> 1) + priority` impose on unused service credit, and does the approach path carry future-relevant behavior beyond a simple hard cap?
