# C001 / P11 discriminator
Is `priority` future-distinguishable from current service credit/counter, or can the current scalar alone preserve all relevant future arbitration behavior?
