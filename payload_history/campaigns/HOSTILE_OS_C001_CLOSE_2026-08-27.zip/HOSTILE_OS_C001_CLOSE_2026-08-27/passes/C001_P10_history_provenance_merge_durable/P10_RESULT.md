# C001 / P10 — Historical cause vs current predictive state

**Disposition:** MERGE-SUPPORTED for arbitration history provenance  
**Scientific pass:** 10

Distinct donor-valid histories can converge to the same current counter. Example at priority 4: an untouched task can have `counter=4`, while a task that accumulated credit and then consumed service can return to the same value.

Once `(counter, priority, eligibility, tie relation, competitor state)` is identical, Linux 0.01's arbitration transition has no input that reveals *why* the counter has that value. The future schedule is therefore identical for histories that converge to the same current state.

The probe enumerated multiple distinct consume/replenish histories reaching the same magnitudes and verified identical future traces after history was erased.

So **historical provenance is not a required scheduler-state plane** for this responsibility. The counter is a sufficient compressed predictive state for the effect of that history on future arbitration. History may still be useful for audit/explanation, but it must not be duplicated into live control state without another discriminator.

This is an ontology merge earned by future equivalence:

`different past -> same current predictive state -> same future arbitration`.

**Next:** test whether `priority` can merge into the same scalar, or whether equal current counters with different priority create different reachable futures after replenishment.
