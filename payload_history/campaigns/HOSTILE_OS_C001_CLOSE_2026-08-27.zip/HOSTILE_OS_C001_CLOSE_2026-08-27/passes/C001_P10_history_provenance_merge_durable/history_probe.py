#!/usr/bin/env python3
from collections import defaultdict,deque
import json
p=4;bound=2*p-1
# enumerate short abstract histories: C consumes if >0, R applies donor replenish transform
paths=defaultdict(list);q=deque([(p,'')]);seen=set([(p,'')])
for depth in range(7):
  for _ in range(len(q)):
    c,path=q.popleft();paths[c].append(path or 'START')
    if c>0:q.append((c-1,path+'C'))
    q.append(((c>>1)+p,path+'R'))
# unique distinct paths per state
multi={c:sorted(set(ps))[:12] for c,ps in paths.items() if len(set(ps))>=2}
# deterministic future simulator from current state only, with fixed competitor trace/actions
def future(a,b=5,steps=16):
  ca=a;cb=b;out=[]
  for _ in range(steps):
    while True:
      # B high rank, A low rank
      if cb>0 or ca>0:
        win='B' if cb>=ca else 'A';break
      ca=(ca>>1)+p;cb=(cb>>1)+p
    if win=='A':ca-=1
    else:cb-=1
    out.append((win,ca,cb))
  return out
checks=[]
for c,ps in multi.items():
  # histories are intentionally discarded; same state must generate same future
  f1=future(c);f2=future(c)
  checks.append({'counter':c,'history_a':ps[0],'history_b':ps[1],'future_equal':f1==f2,'future_prefix':f1[:6]})
assert all(x['future_equal'] for x in checks)
json.dump({'multiple_history_states':multi,'checks':checks},open('evidence/HISTORY_MERGE.json','w'),indent=2)
print(json.dumps({'states_with_multiple_histories':sorted(multi),'sample':checks[:4]},indent=2))
