# Attention Reservoir after P10
- Live arbitration state need not retain causal provenance once current predictive state is equal.
- Audit/history remains separate from operational state.
- Test priority independence next; do not collapse because both are numeric.
